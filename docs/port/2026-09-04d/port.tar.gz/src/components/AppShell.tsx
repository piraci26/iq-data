import { Link } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { iqScreenerQuery } from "@/lib/tht-api";
import { useAuthSession } from "@/hooks/useAuthSession";
import { claimReferral } from "@/lib/affiliate.functions";
import { SiteNav } from "@/components/iq/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { ThemeSwitch } from "@/components/marketing/ThemeSwitch";
import { AppNav } from "@/components/nav/AppNav";

/**
 * Member area shell.
 * One 60px top bar (wordmark, the marketing links, scan chip, theme switch,
 * Log out, avatar), the floating pill rail on the left (bottom tab bar under
 * 768px), then the page content offset 96px for the rail, then the footer.
 * Design system: DM Sans, IBM Plex Mono, steel #3D69A8 as the only accent.
 */

/* App-page top bar right cluster (pill-rail spec §3.3): scan chip (moved up
   from the removed tab strip) · theme switch · Log out · avatar. The avatar
   replaces the black Dashboard pill on app pages only. */

function ScanChip() {
  const { data, isError } = useQuery({ ...iqScreenerQuery(), staleTime: 120_000 });
  const d = data?.updated_at ? new Date(data.updated_at) : null;
  const p = (x: number) => String(x).padStart(2, "0");
  const known = !!d && !isError;
  return (
    <Link
      to="/dashboard"
      aria-label={known ? `Latest scan ${p(d!.getHours())}:${p(d!.getMinutes())}, open the dashboard` : "Scan time unavailable, open the dashboard"}
      style={{
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10.5,
        letterSpacing: "0.14em",
        color: known ? "#3D69A8" : "var(--lp-muted)",
        whiteSpace: "nowrap",
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        textDecoration: "none",
      }}
    >
      <style>{`@keyframes iqScanPulse { 0%,100% { opacity: 1; } 50% { opacity: .35; } }`}</style>
      <span
        aria-hidden
        style={{
          width: 6,
          height: 6,
          borderRadius: "50%",
          background: known ? "#3D69A8" : "var(--lp-muted)",
          animation: known ? "iqScanPulse 1.6s infinite" : "none",
        }}
      />
      {known ? `SCAN ${p(d!.getHours())}:${p(d!.getMinutes())}` : "SCAN —"}
    </Link>
  );
}

function Avatar() {
  const { session } = useAuthSession();
  const meta = (session?.user.user_metadata ?? {}) as Record<string, unknown>;
  const name = [meta.full_name, meta.name, meta.display_name].find((v) => typeof v === "string" && v.trim()) as string | undefined;
  const initial = (name?.trim() || session?.user.email || "·").charAt(0).toUpperCase();
  return (
    <Link
      to="/account"
      aria-label="Account"
      className="iq-app-avatar"
      style={{
        width: 30,
        height: 30,
        borderRadius: "50%",
        background: "rgba(61,105,168,.12)",
        border: "1px solid rgba(61,105,168,.35)",
        color: "#3D69A8",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        textDecoration: "none",
        cursor: "pointer",
        flex: "0 0 auto",
      }}
    >
      {initial}
    </Link>
  );
}

export function AppShell({ children, appFrame = false }: { children: ReactNode; appFrame?: boolean }) {
  const { session } = useAuthSession();

  // One-shot referral claim: if this account arrived through an affiliate link
  // (?ref= captured in __root), attribute it server-side. The server enforces
  // the attribution window and ignores self-referrals; we just never retry a
  // code twice.
  useEffect(() => {
    if (!session?.access_token) return;
    let code: string | null = null;
    try {
      if (window.localStorage.getItem("iq.ref.claimed")) return;
      code = window.localStorage.getItem("iq.ref");
    } catch {
      return;
    }
    if (!code) return;
    try {
      window.localStorage.setItem("iq.ref.claimed", "1");
    } catch { /* ignore */ }
    void claimReferral({ data: { accessToken: session.access_token, code } }).catch(() => undefined);
  }, [session?.access_token]);

  return (
    <div
      style={{
        background: "var(--iq-bg)",
        color: "var(--iq-ink)",
        fontFamily: "'DM Sans', sans-serif",
        minHeight: "100dvh",
        ...(appFrame ? { display: "flex", flexDirection: "column" } : {}),
      }}
    >
      <SiteNav
        fullBleed
        links={[
          { label: "Support", href: "/community" },
        ]}
        app={{
          right: (
            <>
              <ScanChip />
              <span className="iq-app-switch" style={{ display: "inline-flex" }}><ThemeSwitch /></span>
              <Link to="/logout" className="iq-app-logout iq-nav-login" style={{ fontSize: 14.5, fontWeight: 400, color: "var(--lp-body)", textDecoration: "none", whiteSpace: "nowrap", transition: "color .2s" }}>
                Log out
              </Link>
              <Avatar />
            </>
          ),
        }}
      />

      <AppNav />

      <main
        className="iq-app-offset"
        style={
          appFrame
            ? { position: "relative", height: "calc(100dvh - 60px)", flexShrink: 0, display: "flex", flexDirection: "column", overflow: "hidden" }
            : { position: "relative" }
        }
      >
        {children}
      </main>

      <div className="iq-app-offset">
        <SiteFooter />
      </div>
    </div>
  );
}
