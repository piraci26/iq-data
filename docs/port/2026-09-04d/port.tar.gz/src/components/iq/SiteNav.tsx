import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { useAuthSession } from "@/hooks/useAuthSession";
import { NavDropdown, FeatureIcons } from "@/components/NavDropdown";
import { ResourceIcons } from "@/components/features/FeaturesShell";
import { ThemeSwitch } from "@/components/marketing/ThemeSwitch";


/* The wordmark IS the logo — no icon mark. */
export function IQLogo({ variant = "full", withBadge = false, ink }: { variant?: "full" | "mark"; withBadge?: boolean; ink?: string }) {
  return (
    <Link to="/" aria-label="Alpha Charts home" style={{ display: "inline-flex", alignItems: "center", gap: 10, textDecoration: "none", color: ink ?? "#EAF1FC" }}>
      {variant === "full" && (
        <>
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: 17, letterSpacing: "-0.01em" }}>
            Alpha Charts
          </span>
          {withBadge && (
            <span
              style={{
                marginLeft: 4,
                padding: "3px 9px",
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 10,
                letterSpacing: "0.14em",
                fontWeight: 500,
                color: "#8CA3C5",
                border: "1px solid rgba(140,163,197,.35)",
                borderRadius: 999,
                textTransform: "uppercase",
                lineHeight: 1,
                background: "rgba(61,105,168,.08)",
              }}
            >
              CORE v4
            </span>
          )}
        </>
      )}
    </Link>
  );
}

export function FooterLogo() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", color: "var(--lp-ink)" }}>
      <span style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 700, fontSize: 15 }}>Alpha Charts</span>
    </span>
  );
}

const linkStyle: React.CSSProperties = {
  fontSize: 14.5,
  color: "var(--iq-muted)",
  textDecoration: "none",
  padding: "6px 4px",
  fontWeight: 500,
  transition: "color .2s",
  whiteSpace: "nowrap",
};

type NavLink = { label: string; href: string; anchor?: boolean };

export function SiteNav({ links, fullBleed = false, landing = false, app }: { links?: NavLink[]; fullBleed?: boolean; landing?: boolean; app?: { right: ReactNode } }) {
  /* every marketing page is themed (light/dark via the switch); the
     logged-in app shell (fullBleed) keeps its own link colors. `app` is the
     app-page top bar (pill-rail spec §3): one 60px row on the rail surface,
     the marketing links untouched, and a caller-supplied right cluster. */
  const themed = landing || !fullBleed;
  const { isLoading, isAuthenticated } = useAuthSession();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);


  // Default public nav order: Features · Guide · Pricing · Company · FAQ.
  // Absolute anchors so the links work from any page, not just the landing.
  const usingDefault = !links;
  const navLinks: NavLink[] = links ?? [
    { label: "Pricing", href: "/#pricing", anchor: true },
    { label: "FAQ", href: "/#faq", anchor: true },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const prev = document.body.style.overflow;
    if (menuOpen) document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [menuOpen]);

  const companyDropdown = (
    <NavDropdown
      label="Company"
      header={{ label: "About Alpha Charts", href: "/about" }}
      items={[
        { href: "/about", title: "About us", description: "Who builds the tools, and why", icon: ResourceIcons.info },
        { href: "/careers", title: "Careers", description: "Work with us — open roles and pitches", icon: FeatureIcons.listSearch },
        { href: "/affiliates", title: "Affiliates", description: "Recurring commission for sharing the tools", icon: FeatureIcons.broadcast },
      ]}
    />
  );

  const close = () => setMenuOpen(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    setMenuOpen(false);
    setOpenGroup(null);
  }, [pathname]);


  const MOBILE_GROUPS: { label: string; items: NavLink[] }[] = [
    {
      label: "Features",
      items: [
        { label: "Indicators", href: "/indicators" },
        { label: "Screeners", href: "/features/screeners" },
        { label: "Signals", href: "/features/signals" },
        { label: "Algos", href: "/features/algos" },
      ],
    },
    {
      label: "Guide",
      items: [
        { label: "Overview", href: "/guide/overview" },
        { label: "Indicator guides", href: "/guide/iq-bands" },
        { label: "Platform", href: "/guide/signals" },
        { label: "FAQs", href: "/guide/faqs" },
      ],
    },
    {
      label: "Company",
      items: [
        { label: "About us", href: "/about" },
        { label: "Careers", href: "/careers" },
        { label: "Affiliates", href: "/affiliates" },
      ],
    },
  ];

  const mobileRowLabel: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    padding: "18px 0",
    fontSize: 20,
    fontWeight: 600,
    color: "#EAF1FC",
    textDecoration: "none",
    fontFamily: "'DM Sans', sans-serif",
    background: "transparent",
    border: "none",
    textAlign: "left",
    cursor: "pointer",
  };
  const mobileSubItem: React.CSSProperties = {
    display: "block",
    padding: "12px 0 12px 14px",
    fontSize: 15,
    fontWeight: 500,
    color: "var(--iq-muted)",
    textDecoration: "none",
    fontFamily: "'DM Sans', sans-serif",
  };
  const mobileRow: React.CSSProperties = {
    borderBottom: "1px solid var(--iq-line)",
  };
  const mobileBtnBase: React.CSSProperties = {
    display: "block",
    width: "100%",
    textAlign: "center",
    padding: "16px 18px",
    borderRadius: 12,
    fontSize: 16,
    fontWeight: 700,
    textDecoration: "none",
    fontFamily: "'DM Sans', sans-serif",
  };


  const navLinksRow = (
    <div style={{ alignItems: "center", gap: 28 }} className="hidden md:flex iq-nav-desktop-links">
      <span style={{ display: "inline-flex", alignItems: "center", gap: 14, fontSize: 14.5, fontWeight: 500, color: "var(--iq-muted)" }}>
        <NavDropdown
          label="Features"
          header={{ label: "Explore all features", href: "/features" }}
          items={[
            { href: "/indicators", title: "Indicators", description: "The library — flagship suite and free community tools", icon: FeatureIcons.wave },
            { href: "/features/screeners", title: "Screeners", description: "Scan the whole market for fresh triggers", icon: FeatureIcons.listSearch },
            { href: "/features/signals", title: "Signals", description: "Triple signals: 30m, 2H and 1D aligned", icon: FeatureIcons.broadcast },
            { href: "/features/algos", title: "Algos", description: "Turn the read into automated strategies", icon: FeatureIcons.robot },
          ]}
        />
        <NavDropdown
          label="Guide"
          header={{ label: "Open the guide", href: "/guide/overview" }}
          items={[
            { href: "/guide/overview", title: "Overview", description: "Start here — how the system fits together", icon: ResourceIcons.info },
            { href: "/guide/iq-bands", title: "Indicator guides", description: "IQ Bands, Oscillator and Structure, end to end", icon: FeatureIcons.wave },
            { href: "/guide/signals", title: "Platform", description: "Signals, screeners, live tape and the analyst", icon: FeatureIcons.broadcast },
            { href: "/guide/faqs", title: "FAQs", description: "Access, billing and the straight answers", icon: FeatureIcons.listSearch },
          ]}
        />
        {!usingDefault && companyDropdown}
      </span>
      {navLinks.map((l, i) => (
        <span key={l.label} style={{ display: "inline-flex", alignItems: "center", gap: 28 }}>
          {l.anchor ? (
            <a href={l.href} className="iq-nav-link" style={linkStyle}>{l.label}</a>
          ) : (
            <Link to={l.href} className="iq-nav-link" style={linkStyle}>{l.label}</Link>
          )}
          {usingDefault && i === 0 && (
            <span style={{ display: "inline-flex", alignItems: "center", fontSize: 14.5, fontWeight: 500, color: "var(--iq-muted)" }}>
              {companyDropdown}
            </span>
          )}
        </span>
      ))}
    </div>
  );

  return (

    <>
      <style>{`
        .iq-nav-link:hover { color: var(--iq-ink) !important; }
        .iq-nav-white:hover { filter: brightness(.92); }
        .iq-nav-login:hover { color: var(--iq-steel) !important; }
        .iq-nav-burger { display: inline-flex; }
        @media (min-width: 768px) { .iq-nav-burger { display: none !important; } }
        @media (max-width: 767px) {
          .iq-nav-desktop-links { display: none !important; }
          .iq-nav-auth { display: none !important; }
          .iq-nav-inner { padding: 12px 20px !important; gap: 12px !important; }
        }
      `}</style>
      <header
        className={themed ? "lp-landing" : undefined}
        style={{
          position: "sticky",
          top: 0,
          zIndex: 40,
          /* landing (hero spec §4): transparent at the top of the page in
             BOTH themes; the glass appears only once scrolled */
          background: app
            ? "var(--rail-bg)"
            : themed
              ? (scrolled ? "var(--lp-nav-glass)" : "transparent")
              : "var(--iq-glass-nav)",
          backdropFilter: app || (themed && !scrolled) ? "none" : "saturate(160%) blur(16px)",
          WebkitBackdropFilter: app || (themed && !scrolled) ? "none" : "saturate(160%) blur(16px)",
          borderBottom: app
            ? "1px solid var(--lp-hairline)"
            : themed
              ? (scrolled ? "1px solid var(--lp-hairline-soft)" : "1px solid transparent")
              : "1px solid var(--iq-line)",
          transition: "background .2s, border-color .2s",
        }}
      >
        {themed && (
          <style>{`
            .lp-landing .iq-nav-link { color: var(--lp-body) !important; }
            .lp-landing .iq-nav-desktop-links span { color: var(--lp-body); }
            .lp-landing .iq-nav-desktop-links [aria-expanded="true"] { color: var(--lp-ink) !important; }
            [data-theme="dark"] .lp-landing .iq-nav-desktop-links span { color: var(--lp-muted); }
            .lp-landing .iq-nav-link:hover { color: var(--lp-ink) !important; }
            .lp-landing .iq-nav-login { color: var(--lp-body) !important; }
            .lp-landing .iq-nav-login:hover { color: var(--lp-ink) !important; }
            [data-theme="dark"] .lp-landing .iq-nav-link,
            [data-theme="dark"] .lp-landing .iq-nav-login { color: var(--lp-muted) !important; }
            [data-theme="dark"] .lp-landing .iq-nav-link:hover,
            [data-theme="dark"] .lp-landing .iq-nav-login:hover { color: var(--lp-ink) !important; }
          `}</style>
        )}
        <nav
          aria-label="Primary"
          className={"iq-nav-inner" + (app ? " iq-app-topbar" : "")}
          style={{
            /* fullBleed (the logged-in app): logo hard in the left corner,
               actions in the right — the desk gets the whole width. The
               marketing pages keep the centered 1240 column. */
            maxWidth: fullBleed || themed ? "none" : 1240,
            margin: fullBleed || themed ? 0 : "0 auto",
            padding: themed ? "0 48px" : fullBleed ? "14px 20px" : "14px 32px",
            minHeight: themed ? 76 : undefined,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 24,
          }}
        >
          <IQLogo ink={themed || app ? "var(--lp-ink)" : "var(--iq-ink)"} />
          {navLinksRow}


          {app ? (
            <div className="iq-app-cluster" style={{ display: "flex", alignItems: "center", gap: 16 }}>{app.right}</div>
          ) : (
          <div className="iq-nav-auth" style={{ display: "flex", alignItems: "center", gap: themed ? 20 : 14 }}>
            <ThemeSwitch />
            {isLoading ? null : isAuthenticated ? (
              <>
                <Link to="/logout" className="iq-nav-login" style={{ ...linkStyle, color: themed ? "var(--lp-body)" : "var(--iq-ink)", whiteSpace: "nowrap" }}>Log out</Link>

                <Link
                  to="/dashboard"
                  className="iq-nav-white"
                  style={{
                    padding: themed ? "10px 22px" : "9px 18px",
                    borderRadius: 999,
                    background: "var(--lp-cta-bg)",
                    color: "var(--lp-cta-ink)",
                    fontWeight: 700,
                    fontSize: 14,
                    textDecoration: "none",
                    whiteSpace: "nowrap",
                  }}
                >
                  Dashboard
                </Link>
              </>
            ) : (
              <>
                <Link to="/login" className="iq-nav-login" style={{ ...linkStyle, color: themed ? "var(--lp-body)" : "var(--iq-ink)", whiteSpace: "nowrap" }}>{themed ? "Login" : "Log in"}</Link>
                <Link
                  to="/signup"
                  className="iq-nav-white"
                  style={{
                    padding: themed ? "10px 22px" : "9px 18px",
                    borderRadius: 999,
                    background: "var(--lp-cta-bg)",
                    color: "var(--lp-cta-ink)",
                    fontWeight: 700,
                    fontSize: 14,
                    textDecoration: "none",
                    whiteSpace: "nowrap",
                  }}
                >
                  {themed ? "Get Alpha Charts" : "Get access"}
                </Link>
              </>
            )}
          </div>
          )}

          {/* Mobile hamburger */}
          <button
            type="button"
            className="iq-nav-burger"
            aria-label="Open menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(true)}
            style={{
              width: 44,
              height: 44,
              alignItems: "center",
              justifyContent: "center",
              background: "transparent",
              border: "none",
              color: "#EAF1FC",
              cursor: "pointer",
              padding: 0,
              marginRight: -8,
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </nav>
      </header>

      {menuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 100,
            background: "rgba(5,5,5,.97)",
            backdropFilter: "blur(14px)",
            overflowY: "auto",
            fontFamily: "'DM Sans', sans-serif",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 20px", borderBottom: "1px solid rgba(255,255,255,.08)" }}>
            <span onClick={close}>
              <IQLogo />

            </span>
            <button
              type="button"
              aria-label="Close menu"
              onClick={close}
              style={{
                width: 44,
                height: 44,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                background: "transparent",
                border: "none",
                color: "#EAF1FC",
                cursor: "pointer",
                marginRight: -8,
              }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </button>
          </div>

          <div style={{ padding: "4px 20px 48px" }}>
            {MOBILE_GROUPS.map((g) => {
              const open = openGroup === g.label;
              return (
                <div key={g.label} style={mobileRow}>
                  <button
                    type="button"
                    aria-expanded={open}
                    onClick={() => setOpenGroup(open ? null : g.label)}
                    style={mobileRowLabel}
                  >
                    {g.label}
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      aria-hidden="true"
                      style={{ transition: "transform .2s ease", transform: open ? "rotate(180deg)" : "none", color: "var(--iq-muted)" }}
                    >
                      <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  {open && (
                    <div style={{ paddingBottom: 12 }}>
                      {g.items.map((it) => (
                        <Link key={it.href} to={it.href} onClick={close} style={mobileSubItem}>
                          {it.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {navLinks.map((l) =>
              l.anchor ? (
                <a key={l.href} href={l.href} onClick={close} style={{ ...mobileRowLabel, ...mobileRow }}>
                  {l.label}
                </a>
              ) : (
                <Link key={l.href} to={l.href} onClick={close} style={{ ...mobileRowLabel, ...mobileRow }}>
                  {l.label}
                </Link>
              )
            )}

            <div style={{ marginTop: 32, display: "flex", flexDirection: "column", gap: 12 }}>
              {isLoading ? null : isAuthenticated ? (
                <>
                  <Link to="/dashboard" onClick={close} style={{ ...mobileBtnBase, background: "#3D69A8", color: "#fff" }}>
                    Dashboard
                  </Link>
                  <Link
                    to="/logout"
                    onClick={close}
                    style={{ ...mobileBtnBase, border: "1px solid rgba(255,255,255,.2)", color: "#EAF1FC" }}
                  >
                    Log out
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    onClick={close}
                    style={{ ...mobileBtnBase, border: "1px solid rgba(255,255,255,.2)", color: "#EAF1FC" }}
                  >
                    Log in
                  </Link>
                  <Link to="/signup" onClick={close} style={{ ...mobileBtnBase, background: "#3D69A8", color: "#fff" }}>
                    Get access
                  </Link>
                </>
              )}
            </div>
          </div>

        </div>
      )}
    </>
  );
}

