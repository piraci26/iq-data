import { BottomTabBar } from "@/components/nav/BottomTabBar";
import { PillRail } from "@/components/nav/PillRail";
import { useMediaQuery } from "@/components/nav/useMediaQuery";

/* Mounts the rail (≥768px) or the bottom tab bar (<768px); any pinned or
   open state is dropped on the swap because the component unmounts (§13.6). */
export function AppNav() {
  const wide = useMediaQuery("(min-width: 768px)");
  return wide ? <PillRail /> : <BottomTabBar />;
}
