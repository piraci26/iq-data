import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { APP_NAV, activeFor, groupById, type AppNavGroup } from "@/lib/appNav";

/* The floating pill rail (app navigation spec §4–§7, §12): four icons in a
   detached, fully rounded dock on the left edge, a flyout for groups with
   children, a tooltip for Dashboard. Desktop and tablet only; the bottom
   tab bar replaces it under 768px. Geometry and timings are the spec's. */

type Gid = AppNavGroup["id"];
const hasChildren = (g: Gid) => groupById(g).children.length > 0;
const isTyping = () => {
  const el = document.activeElement as HTMLElement | null;
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
};
const modalOpen = () => !!document.querySelector('[aria-modal="true"], [role="dialog"]');

export function PillRail() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const active = activeFor(pathname);

  const [hover, setHover] = useState<Gid | null>(null);
  const [pinned, setPinned] = useState<Gid | null>(null);
  const [focus, setFocus] = useState<Gid | null>(null);
  const [tip, setTip] = useState(false);
  const [tipTop, setTipTop] = useState(0);
  const [animateIn, setAnimateIn] = useState(false); // first-open animation only (§10): class, never a remount
  const [closing, setClosing] = useState<Gid | null>(null);

  const hoverT = useRef<number | null>(null);
  const leaveT = useRef<number | null>(null);
  const tipT = useRef<number | null>(null);
  const closeT = useRef<number | null>(null);
  const navRef = useRef<HTMLElement>(null);
  const itemRefs = useRef<Record<number, HTMLElement | null>>({});
  const flyoutRef = useRef<HTMLDivElement>(null);
  const prevVisible = useRef<Gid | null>(null);
  const skipFocusOpen = useRef(false); // Esc returns focus to the rail without re-opening (§7.2 Esc, §15.3)

  const clear = (r: React.MutableRefObject<number | null>) => { if (r.current) { window.clearTimeout(r.current); r.current = null; } };

  const candidate = pinned ?? hover ?? focus;
  const visible: Gid | null = candidate && hasChildren(candidate) ? candidate : null;
  const tipVisible = tip && !pinned && (hover === 1 || focus === 1);

  /* first-open animation only: bump the session key on null → group */
  useEffect(() => {
    if (visible && !prevVisible.current) { setAnimateIn(true); clear(closeT); setClosing(null); }
    if (visible && prevVisible.current && visible !== prevVisible.current) setAnimateIn(false); // swap in place, no re-animation
    if (!visible && prevVisible.current) {
      const last = prevVisible.current;
      setClosing(last);
      clear(closeT);
      closeT.current = window.setTimeout(() => setClosing(null), 120);
    }
    prevVisible.current = visible;
  }, [visible]);

  /* route change: everything closes, active markers recompute from the path */
  useEffect(() => { setPinned(null); setHover(null); setTip(false); }, [pathname]);

  /* click outside closes a pinned flyout */
  useEffect(() => {
    if (!pinned) return;
    const onDown = (e: PointerEvent) => { if (!navRef.current?.contains(e.target as Node)) setPinned(null); };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [pinned]);

  const focusRail = useCallback((g: Gid) => { itemRefs.current[g]?.focus(); }, []);
  const childLinks = () => Array.from(flyoutRef.current?.querySelectorAll<HTMLAnchorElement>('[role="menuitem"]') ?? []);
  const focusChild = (i: number) => { const ls = childLinks(); ls[Math.max(0, Math.min(i, ls.length - 1))]?.focus(); };
  const focusActiveOrFirstChild = () => {
    const ls = childLinks();
    const i = ls.findIndex((l) => l.getAttribute("aria-current") === "page");
    (i >= 0 ? ls[i] : ls[0])?.focus();
  };

  /* global shortcuts 1–4 and Esc (§7.3 guards) */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && (visible || closing || tipVisible || pinned)) {
        setPinned(null); setHover(null); setTip(false); setFocus(null);
        if (active.groupId) { skipFocusOpen.current = true; focusRail(active.groupId); skipFocusOpen.current = false; }
        return;
      }
      if (!["1", "2", "3", "4"].includes(e.key)) return;
      if (e.metaKey || e.ctrlKey || e.altKey || e.shiftKey || isTyping() || modalOpen()) return;
      const g = Number(e.key) as Gid;
      e.preventDefault();
      focusRail(g);
      if (hasChildren(g)) { setPinned(g); setHover(null); window.setTimeout(focusActiveOrFirstChild, 0); }
      else void navigate({ to: groupById(g).href! });
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [visible, closing, tipVisible, pinned, active.groupId, focusRail, navigate]);

  const onItemEnter = (g: Gid) => {
    clear(leaveT); clear(hoverT); clear(tipT);
    if (hasChildren(g)) hoverT.current = window.setTimeout(() => setHover(g), 120);
    else {
      setHover(g);
      tipT.current = window.setTimeout(() => { placeTip(g); setTip(true); }, 300);
    }
  };
  const placeTip = (g: Gid) => {
    const r = itemRefs.current[g]?.getBoundingClientRect();
    if (r) setTipTop(r.top + r.height / 2);
  };
  const onRegionLeave = () => {
    clear(hoverT); clear(tipT);
    leaveT.current = window.setTimeout(() => { setHover(null); setTip(false); }, 200);
  };
  const onRegionEnter = () => { clear(leaveT); };
  const onItemClick = (g: Gid, e: React.MouseEvent) => {
    if (!hasChildren(g)) { setPinned(null); setTip(false); return; } // Link navigates
    e.preventDefault();
    setPinned((p) => (p === g ? null : g));
    setHover(null);
  };
  const onItemFocus = (g: Gid) => {
    if (skipFocusOpen.current) return; // programmatic focus after Esc: closed stays closed until ↓/→/Tab
    setFocus(g);
    if (!hasChildren(g)) { placeTip(g); setTip(true); }
  };
  const onItemBlur = () => { setFocus(null); };

  const railKey = (e: React.KeyboardEvent, g: Gid) => {
    const order: Gid[] = [1, 2, 3, 4];
    const i = order.indexOf(g);
    if (e.key === "ArrowDown") { e.preventDefault(); focusRail(order[(i + 1) % 4]); }
    else if (e.key === "ArrowUp") { e.preventDefault(); focusRail(order[(i + 3) % 4]); }
    else if ((e.key === "ArrowRight" || e.key === "Enter" || e.key === " ") && hasChildren(g)) {
      e.preventDefault(); setPinned(g); setHover(null); window.setTimeout(focusActiveOrFirstChild, 0);
    }
  };
  const flyoutKey = (e: React.KeyboardEvent) => {
    const ls = childLinks();
    const i = ls.indexOf(document.activeElement as HTMLAnchorElement);
    const g = visible ?? closing;
    if (e.key === "ArrowDown") { e.preventDefault(); if (i < ls.length - 1) focusChild(i + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); if (i <= 0) { if (g) focusRail(g); } else focusChild(i - 1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); setPinned(null); if (g) focusRail(g); }
    else if (e.key === "Home") { e.preventDefault(); focusChild(0); }
    else if (e.key === "End") { e.preventDefault(); focusChild(ls.length - 1); }
  };

  const shownGroup = visible ?? closing;
  const flyoutGroup = shownGroup ? groupById(shownGroup) : null;
  const tabStop = active.groupId ?? 1;

  return (
    <nav aria-label="App sections" className="iq-rail-wrap" ref={navRef} onPointerEnter={onRegionEnter} onPointerLeave={onRegionLeave}>
      <div className="iq-rail">
        {APP_NAV.map((g) => {
          const isActive = active.groupId === g.id;
          const common = {
            className: "iq-rail-item",
            "aria-label": g.label,
            "aria-current": isActive ? ("true" as const) : undefined,
            tabIndex: g.id === tabStop ? 0 : -1,
            onPointerEnter: () => onItemEnter(g.id),
            onFocus: () => onItemFocus(g.id),
            onBlur: onItemBlur,
            onKeyDown: (e: React.KeyboardEvent) => railKey(e, g.id),
            "data-group": g.id,
          };
          return g.children.length === 0 ? (
            <Link
              key={g.id}
              to={g.href!}
              ref={(el) => { itemRefs.current[g.id] = el; }}
              aria-describedby="iq-tip-dash"
              onClick={(e) => onItemClick(g.id, e)}
              {...common}
            >
              <span aria-hidden>{g.glyph}</span>
            </Link>
          ) : (
            <button
              key={g.id}
              type="button"
              ref={(el) => { itemRefs.current[g.id] = el; }}
              aria-haspopup="menu"
              aria-expanded={visible === g.id}
              aria-controls="iq-flyout"
              onClick={(e) => onItemClick(g.id, e)}
              {...common}
            >
              <span aria-hidden>{g.glyph}</span>
            </button>
          );
        })}
      </div>

      <div className="iq-rail-bridge" aria-hidden />

      {flyoutGroup && (
        <div
          id="iq-flyout"
          ref={flyoutRef}
          role="menu"
          aria-label={flyoutGroup.label}
          className={"iq-flyout" + (visible ? (animateIn ? " iq-flyout--in" : "") : " iq-flyout--out")}
          onKeyDown={flyoutKey}
          onAnimationEnd={() => setAnimateIn(false)}
        >
          <div className="iq-flyout-eyebrow">{flyoutGroup.eyebrow}</div>
          {flyoutGroup.children.map((c, i) => {
            const on = active.childHref === c.href && flyoutGroup.children.findIndex((x) => x.href === c.href) === i;
            return (
              <Link
                key={c.label}
                to={c.href}
                role="menuitem"
                tabIndex={-1}
                aria-current={on ? "page" : undefined}
                onClick={() => { setPinned(null); setHover(null); }}
              >
                {c.label}
                {on && <span className="iq-flyout-check" aria-hidden>✓</span>}
              </Link>
            );
          })}
        </div>
      )}

      <div id="iq-tip-dash" role="tooltip" className={"iq-tooltip" + (tipVisible ? " iq-tooltip--on" : "")} style={{ top: tipTop }}>
        Dashboard
      </div>
    </nav>
  );
}
