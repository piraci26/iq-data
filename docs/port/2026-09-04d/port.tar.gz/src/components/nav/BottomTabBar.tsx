import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { APP_NAV, MOBILE_LABELS, activeFor, groupById, type AppNavGroup } from "@/lib/appNav";

/* Under 768px the rail is replaced by a bottom tab bar; groups with
   children open a bottom sheet (spec §11.1). Same config, same order. */

type Gid = AppNavGroup["id"];

const Glyph = ({ id }: { id: Gid }) => {
  /* the same four shapes as the rail, drawn as SVG at 20px (spec §8) */
  const common = { width: 20, height: 20, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  if (id === 1) return <svg {...common}><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M12 4v16" /></svg>;
  if (id === 2) return <svg {...common}><path d="M12 3l9 9-9 9-9-9z" /><path d="M12 8.5l3.5 3.5-3.5 3.5L8.5 12z" /></svg>;
  if (id === 3) return <svg {...common}><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M3 10h18M3 15h18" /></svg>;
  return <svg {...common}><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M12 4v16M3 12h18" /></svg>;
};

export function BottomTabBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const active = activeFor(pathname);
  const [sheet, setSheet] = useState<Gid | null>(null);
  const startY = useRef<number | null>(null);

  useEffect(() => { setSheet(null); }, [pathname]);
  useEffect(() => {
    if (!sheet) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setSheet(null); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [sheet]);

  const group = sheet ? groupById(sheet) : null;

  return (
    <>
      <nav aria-label="App sections" className="iq-bottombar">
        {APP_NAV.map((g) => {
          const on = active.groupId === g.id;
          const cls = "iq-bottombar-cell" + (on ? " iq-bottombar-cell--on" : "");
          return g.children.length === 0 ? (
            <Link key={g.id} to={g.href!} className={cls} aria-current={on ? "page" : undefined} aria-label={g.label} onClick={() => setSheet(null)}>
              <Glyph id={g.id} />
              <span>{MOBILE_LABELS[g.id]}</span>
            </Link>
          ) : (
            <button key={g.id} type="button" className={cls} aria-current={on ? "true" : undefined} aria-haspopup="dialog" aria-expanded={sheet === g.id} aria-label={g.label} onClick={() => setSheet((s) => (s === g.id ? null : g.id))}>
              <Glyph id={g.id} />
              <span>{MOBILE_LABELS[g.id]}</span>
            </button>
          );
        })}
      </nav>

      {group && (
        <div className="iq-sheet-backdrop" onClick={() => setSheet(null)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-label={group.label}
            className="iq-sheet"
            onClick={(e) => e.stopPropagation()}
            onTouchStart={(e) => { startY.current = e.touches[0].clientY; }}
            onTouchMove={(e) => { if (startY.current != null && e.touches[0].clientY - startY.current > 60) { startY.current = null; setSheet(null); } }}
          >
            <div className="iq-sheet-handle" aria-hidden />
            <div className="iq-sheet-title">{group.label}</div>
            {group.children.map((c) => {
              const on = active.childHref === c.href;
              return (
                <Link key={c.label} to={c.href} className={"iq-sheet-item" + (on ? " iq-sheet-item--on" : "")} aria-current={on ? "page" : undefined} onClick={() => setSheet(null)}>
                  {c.label}
                  {on && <span className="iq-flyout-check" aria-hidden>✓</span>}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}
