import { useEffect, useState } from "react";

/* SSR-safe media query hook: the first render (server and hydration) always
   uses `initial`, the real answer arrives from the effect right after mount.
   Reading matchMedia during the first client render would make the hydrated
   tree differ from the server's on narrow viewports (React hydration error). */
export function useMediaQuery(query: string, initial = true): boolean {
  const [matches, setMatches] = useState(initial);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setMatches(mq.matches);
    onChange();
    mq.addEventListener("change", onChange);
    window.addEventListener("resize", onChange); // belt and braces: some embedded viewers defer MQL change events
    return () => { mq.removeEventListener("change", onChange); window.removeEventListener("resize", onChange); };
  }, [query]);
  return matches;
}
