import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { SiteNav } from "@/components/iq/SiteNav";
import { HeroWindow } from "@/components/marketing/HeroWindow";
import { CopilotDemo } from "@/components/marketing/CopilotDemo";
import { RepaintDemo, BacktestDemo, BrokerDemo, VersionDemo, DEMO_CSS } from "@/components/marketing/Demos";
import InferenceTerminal from "@/components/iq/InferenceTerminal";
import { SiteFooter } from "@/components/SiteFooter";
import chartAAsset from "@/assets/chart-a.png.asset.json";
import iqBandsAsset from "@/assets/iq-bands.png.asset.json";
import iqOscAsset from "@/assets/iq-oscillator.png.asset.json";

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "Alpha Charts | We make the scripts. You make the trades." },
      { name: "description", content: "TradingView indicators that lock on close and never repaint, a library of scripts, and a copilot that writes yours in Pine v6 and checks it before you paste." },
    ],
  }),
});

// ---------- primitives ----------
const MAX = 1240;
const wrap: React.CSSProperties = { maxWidth: MAX, margin: "0 auto", padding: "0 32px" };
const eyebrow = (color = "var(--lp-muted)"): React.CSSProperties => ({
  fontFamily: "'IBM Plex Mono', monospace",
  fontSize: 12,
  letterSpacing: "0.2em",
  textTransform: "uppercase",
  color,
  marginBottom: 16,
});
const h2Style: React.CSSProperties = {
  fontFamily: "'DM Sans', sans-serif",
  fontSize: 56,
  fontWeight: 700,
  letterSpacing: "-0.025em",
  lineHeight: 1,
  color: "var(--lp-ink)",
  margin: 0,
};
const bodyMuted: React.CSSProperties = { color: "var(--lp-body)", fontSize: 17, lineHeight: 1.6, margin: 0 };
const hairline = "1px solid var(--lp-seam-hairline)";
const cardBase: React.CSSProperties = {
  border: hairline,
  borderRadius: 20,
  background: "var(--lp-card)",
  transition: "border-color .3s",
};

function Reveal({ children, style, delay = 0, blur = false }: { children: React.ReactNode; style?: React.CSSProperties; delay?: number; blur?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVis(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setVis(true);
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      style={{
        ...style,
        opacity: vis ? 1 : 0,
        transform: vis ? "translateY(0)" : "translateY(20px)",
        filter: blur ? (vis ? "blur(0px)" : "blur(10px)") : undefined,
        transition: `opacity .7s ease ${delay}ms, transform .7s cubic-bezier(.2,.8,.2,1) ${delay}ms, filter .8s ease ${delay}ms`,
        willChange: "opacity, transform",
      }}
    >
      {children}
    </div>
  );
}

const btnPrimary: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 6,
  padding: "16px 32px",
  borderRadius: 999,
  background: "#3D69A8",
  color: "#fff",
  fontWeight: 700,
  fontSize: 16,
  textDecoration: "none",
  border: "none",
  cursor: "pointer",
  boxShadow: "0 0 0 1px rgba(255,255,255,.14) inset, 0 14px 44px rgba(61,105,168,.3), 0 0 80px rgba(61,105,168,.35)",
  transition: "filter .2s, transform .2s",
};
const btnSecondary: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "16px 32px",
  borderRadius: 999,
  background: "var(--lp-chip-bg)",
  color: "var(--lp-ink)",
  fontWeight: 600,
  fontSize: 16,
  textDecoration: "none",
  border: "1px solid var(--lp-hairline-strong)",
  cursor: "pointer",
  transition: "border-color .2s",
};

// ---------- Hero (redesign spec v2: typography-led, two themes) ----------
const IDEAS = ["squeeze breakout on NQ, 5 minute, no lookahead", "VWAP reclaim on ES with a daily trend filter", "RSI divergence that only fires on the closed bar", "opening range break, alerts to Alpaca"];
function useTypingPlaceholder() {
  const [text, setText] = useState(IDEAS[0]);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let i = 0, k = IDEAS[0].length, dir = -1, timer = 0;
    const tick = () => {
      k += dir;
      if (dir < 0 && k <= 0) { dir = 1; i = (i + 1) % IDEAS.length; }
      if (dir > 0 && k >= IDEAS[i].length) { dir = -1; timer = window.setTimeout(tick, 2200); setText(IDEAS[i]); return; }
      setText(IDEAS[i].slice(0, Math.max(0, k)));
      timer = window.setTimeout(tick, dir > 0 ? 38 : 16);
    };
    timer = window.setTimeout(tick, 1800);
    return () => window.clearTimeout(timer);
  }, []);
  return text;
}

function Hero() {
  /* dev-only: ?demo_t=<ms> freezes the hero demo at one frame (storyboard checks) */
  const search = useRouterState({ select: (s) => s.location.search as unknown as Record<string, unknown> });
  const raw = search && typeof search === "object" ? (search as Record<string, unknown>).demo_t : undefined;
  const demoClock = typeof raw === "number" ? raw : typeof raw === "string" && raw !== "" && !Number.isNaN(Number(raw)) ? Number(raw) : undefined;
  return (
    <section
      style={{
        position: "relative",
        /* the window is FULLY visible (owner 2026-08-31, LuxAlgo reference):
           no fold crop — the hero flows and the page scrolls past it */
        minHeight: "calc(100vh - 76px)",
        textAlign: "center",
        background: "var(--lp-bg-hero)",
      }}
    >
      <style>{`
        /* dark-only static light shaft (§6.5) — never animated */
        .lp-beam { display: none; }
        [data-theme="dark"] .lp-beam {
          display: block; position: absolute; inset: 0; pointer-events: none;
          background: linear-gradient(112deg, transparent 40%, rgba(61,105,168,.05) 49%, rgba(108,140,186,.10) 53%, rgba(61,105,168,.04) 58%, transparent 68%);
        }
        .lp-h1 { font-size: 72px; letter-spacing: -.035em; }
        @media (max-width: 1279px) { .lp-h1 { font-size: 60px; } }
        @media (max-width: 1023px) { .lp-h1 { font-size: 48px; letter-spacing: -.03em; } }
        @media (max-width: 767px)  { .lp-h1 { font-size: 38px; } }
        .lp-sub { font-size: 17px; max-width: 560px; }
        @media (max-width: 1023px) { .lp-sub { font-size: 16px; max-width: 84vw; } }
        @media (max-width: 767px)  { .lp-sub { font-size: 15px; } }
        .lp-ctas { display: flex; justify-content: center; gap: 10px; }
        @media (max-width: 767px)  { .lp-ctas { flex-direction: column; align-items: center; } .lp-ctas a { width: 100%; max-width: 320px; } }
        .lp-cta-pri:hover { filter: brightness(1.08); }
        [data-theme="dark"] .lp-cta-pri:hover { filter: brightness(.92); }
        .lp-cta-sec:hover { border-color: rgba(61,105,168,.45) !important; }
        .lp-badge:hover { border-color: rgba(61,105,168,.45) !important; }
        @keyframes lpIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        .lp-in { opacity: 0; animation: lpIn .35s ease forwards; }
        .lp-in-1 { animation-delay: 0s; } .lp-in-2 { animation-delay: .06s; }
        .lp-in-3 { animation-delay: .12s; } .lp-in-4 { animation-delay: .18s; }
        .lp-in-5 { animation-delay: .24s; }
        @media (prefers-reduced-motion: reduce) { .lp-in { animation: none; opacity: 1; } }
      `}</style>
      <div className="lp-beam" aria-hidden="true" />

      <div style={{ position: "relative", maxWidth: 1200, margin: "0 auto", padding: "0 16px" }}>
        {/* §6 row 1: the intentional empty air band — grows on tall
            viewports, shrinks first (to 48px) on short ones */}
        <div style={{ height: 64 }} aria-hidden="true" />

        {/* badge */}
        <a
          href="/features"
          className="lp-in lp-in-1 lp-badge"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 9,
            borderRadius: 999,
            padding: "6px 16px 6px 6px",
            background: "var(--lp-chip-bg)",
            border: "1px solid var(--lp-badge-border)",
            boxShadow: "var(--lp-chip-shadow)",
            textDecoration: "none",
            transition: "border-color .2s ease",
          }}
        >
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, letterSpacing: ".1em", borderRadius: 999, padding: "3px 9px", background: "var(--lp-newchip-bg)", color: "var(--lp-newchip-ink)" }}>NEW</span>
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--lp-body)" }}>New · Pine Copilot, checked before you paste</span>
        </a>

        {/* headline — solid ink, two lines, no period */}
        <h1
          className="lp-in lp-in-2 lp-h1"
          style={{
            fontFamily: "'DM Sans', sans-serif",
            fontWeight: 800,
            lineHeight: 1.05,
            color: "var(--lp-ink)",
            margin: "44px auto 0",
          }}
        >
          We make the scripts.
          <br />
          You make the trades.
        </h1>

        {/* subline */}
        <p className="lp-in lp-in-3 lp-sub" style={{ fontFamily: "'DM Sans', sans-serif", lineHeight: 1.6, color: "var(--lp-muted)", margin: "18px auto 0" }}>
          Our indicators, a library of ready scripts, and a copilot that writes yours in Pine v6. Locked on close, checked before you paste.
        </p>

        {/* CTAs */}
        <div className="lp-in lp-in-4 lp-ctas" style={{ marginTop: 34 }}>
          <a
            href="/signup"
            className="lp-cta-pri"
            style={{
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              borderRadius: 999, padding: "13px 28px",
              fontFamily: "'DM Sans', sans-serif", fontSize: 14, fontWeight: 700,
              background: "var(--lp-cta-bg)", color: "var(--lp-cta-ink)",
              boxShadow: "var(--lp-cta-shadow)", textDecoration: "none",
              transition: "filter .2s ease",
            }}
          >
            Write my first script →
          </a>
          <a
            href="/indicators"
            className="lp-cta-sec"
            style={{
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              borderRadius: 999, padding: "12px 24px",
              fontFamily: "'DM Sans', sans-serif", fontSize: 14, fontWeight: 600,
              background: "var(--lp-chip-bg)", color: "var(--lp-ink)",
              border: "1px solid var(--lp-hairline-strong)", textDecoration: "none",
              transition: "border-color .2s ease",
            }}
          >
            See the scripts
          </a>
        </div>

        {/* the product window — fully visible, ticker strip follows */}
        <div className="lp-in lp-in-5" style={{ marginTop: 52, paddingBottom: 72 }}>
          <CopilotDemo clock={demoClock} />
        </div>
      </div>
    </section>
  );
}

// ---------- Ticker ----------
const TICKER_ITEMS = [
  { sym: "NQ1! TREND", arrow: "▲", color: "#089981" },
  { sym: "ES1! TREND", arrow: "▲", color: "#089981" },
  { sym: "EURUSD REGIME", arrow: "▼", color: "#F23645" },
  { sym: "BTCUSD TREND", arrow: "▲", color: "#089981" },
  { sym: "XAUUSD RANGE", arrow: "·", color: "#8595B4" },
  { sym: "AAPL TREND", arrow: "▲", color: "#089981" },
  { sym: "CL1! REGIME", arrow: "▼", color: "#F23645" },
  { sym: "SPY TREND", arrow: "▲", color: "#089981" },
  { sym: "DXY RANGE", arrow: "·", color: "#8595B4" },
];

function Ticker() {
  return (
    <section style={{ borderTop: hairline, borderBottom: hairline, background: "rgba(255,255,255,.012)" }}>
      <div style={{ ...wrap, padding: "18px 32px", display: "flex", alignItems: "center", gap: 28 }}>
        <span
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            color: "var(--lp-muted)",
            letterSpacing: "0.14em",
            whiteSpace: "nowrap",
            flexShrink: 0,
          }}
        >
          TRACKS EVERY MARKET
        </span>
        <div
          style={{
            overflow: "hidden",
            flex: 1,
            WebkitMaskImage: "linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)",
            maskImage: "linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)",
          }}
        >
          <div style={{ display: "flex", width: "max-content", gap: 46, animation: "marquee 30s linear infinite", fontFamily: "'IBM Plex Mono', monospace", fontSize: 13 }}>
            {[...TICKER_ITEMS, ...TICKER_ITEMS].map((it, i) => (
              <span key={i} style={{ color: "#8595B4", whiteSpace: "nowrap" }}>
                {it.sym.split(" ").slice(0, -1).join(" ")}{" "}
                <span style={{ color: "#8595B4" }}>{it.sym.split(" ").slice(-1)[0]}</span>{" "}
                <span style={{ color: it.color }}>{it.arrow}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------- System bento ----------
function ChartPlaceholder({ label }: { label: string }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#5C6E93", /* window-label constant — product imagery is unthemed */
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11,
        letterSpacing: "0.2em",
      }}
    >
      {label}
    </div>
  );
}

function SystemSection() {
  const statusRow = (label: string, val: string, opts: { bg?: string; border?: string; color?: string; glow?: boolean } = {}) => (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "13px 16px",
        borderRadius: 11,
        border: `1px solid ${opts.border || "rgba(255,255,255,.08)"}`,
        background: opts.bg || "transparent",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 12.5,
        boxShadow: opts.glow ? "0 0 30px rgba(61,105,168,.15)" : "none",
      }}
    >
      <span style={{ color: "#9DB2D4" }}>{label}</span>
      <span style={{ color: opts.color || "var(--lp-ink)", fontWeight: 600 }}>{val}</span>
    </div>
  );

  return (
    <section id="system" style={{ ...wrap, paddingTop: 110, paddingBottom: 40 }}>
      <Reveal blur>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 40, flexWrap: "wrap" }}>
        <div>
          <div style={eyebrow("#8CA3C5")}>THE SYSTEM</div>
          <h2 style={h2Style}>
            Three engines.
            <br />
            One decision.
          </h2>
        </div>
        <p style={{ ...bodyMuted, maxWidth: 400 }}>
          Everything on this page runs live on your TradingView chart. This is the actual output, not a render.
        </p>
      </div>
      </Reveal>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 18, marginTop: 52 }}>
        {/* Card A - big chart */}
        <Reveal style={{ gridColumn: "span 8" }}>
          <div style={{ ...cardBase, background: "#0D0D0D", overflow: "hidden", boxShadow: "0 30px 90px rgba(0,0,0,.5)", height: "100%" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "14px 20px",
                borderBottom: hairline,
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 11.5,
              }}
            >
              <span style={{ color: "var(--lp-ink)" }}>● NQ1! · 15M · REGIME ENGINE</span>
              <span style={{ color: "#089981" }}>TREND ▲ · 0.94</span>
            </div>
            <div style={{ position: "relative", height: 400, background: "#0D0D0D" }}>
              <img src={chartAAsset.url} alt="" aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", mixBlendMode: "screen" }} />
              {/* scanline */}
              <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
                <div style={{ position: "absolute", left: 0, right: 0, height: 60, background: "linear-gradient(180deg, transparent, rgba(61,105,168,.08), transparent)", animation: "scanline 5.5s linear infinite" }} />
              </div>
              {/* chips */}
              <div style={{ position: "absolute", left: 24, bottom: 20, display: "flex", gap: 8 }}>
                <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, padding: "6px 12px", borderRadius: 8, background: "rgba(8,18,14,.85)", border: "1px solid rgba(8,153,129,.4)", color: "#D9F8E9" }}>
                  IN EARLY · 20,318
                </span>
                <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, padding: "6px 12px", borderRadius: 8, background: "rgba(12,12,12,.85)", border: hairline, color: "#B9C7E2" }}>
                  HOLDING · +212 pts
                </span>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Card B - live state */}
        <Reveal style={{ gridColumn: "span 4" }} delay={80}>
          <div style={{ ...cardBase, padding: 26, height: "100%", display: "flex", flexDirection: "column" }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "var(--lp-muted)", letterSpacing: "0.2em" }}>LIVE STATE</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 22 }}>
              {statusRow("Regime", "TREND ▲", { bg: "rgba(8,153,129,.07)", border: "rgba(8,153,129,.25)", color: "#089981" })}
              {statusRow("Momentum", "RISING ▲", { bg: "rgba(8,153,129,.07)", border: "rgba(8,153,129,.25)", color: "#089981" })}
              {statusRow("Signal", "LOCKED ●", { bg: "rgba(61,105,168,.08)", border: "rgba(61,105,168,.35)", color: "#8CA3C5", glow: true })}
              {statusRow("Alerts", "ARMED")}
            </div>
            <p style={{ ...bodyMuted, fontSize: 14, marginTop: 20 }}>
              When both engines agree, the signal locks, and your phone knows before you do.
            </p>
          </div>
        </Reveal>

        {/* Card C */}
        <Reveal style={{ gridColumn: "span 4" }}>
          <div style={{ ...cardBase, padding: 26, height: "100%", display: "flex", flexDirection: "column", gap: 18 }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#089981", letterSpacing: "0.2em" }}>ENGINE 01 · IQ BANDS</div>
            <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 21, fontWeight: 700, color: "var(--lp-ink)", margin: 0 }}>The regime, drawn on price</h3>
            <p style={{ ...bodyMuted, fontSize: 15 }}>
              A volatility envelope that holds the trend and flips only when the market changes character. In early,
              quiet through the chop.
            </p>
            <div style={{ position: "relative", height: 150, borderRadius: 12, border: hairline, background: "#0D0D0D", overflow: "hidden" }}>
              <img src={iqBandsAsset.url} alt="" aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transform: "scale(1.3)", mixBlendMode: "screen" }} />
            </div>
          </div>
        </Reveal>

        {/* Card D */}
        <Reveal style={{ gridColumn: "span 4" }} delay={60}>
          <div style={{ ...cardBase, padding: 26, height: "100%", display: "flex", flexDirection: "column", gap: 18 }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#8CA3C5", letterSpacing: "0.2em" }}>ENGINE 02 · IQ OSCILLATOR</div>
            <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 21, fontWeight: 700, color: "var(--lp-ink)", margin: 0 }}>Momentum, measured beneath it</h3>
            <p style={{ ...bodyMuted, fontSize: 15 }}>
              The confirming lens below price. It catches the turn, flags divergence, and has to agree before anything
              fires.
            </p>
            <div style={{ position: "relative", height: 150, borderRadius: 12, border: hairline, background: "#0D0D0D", overflow: "hidden" }}>
              <img src={iqOscAsset.url} alt="" aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transform: "scale(1.26)", transformOrigin: "50% 72%", mixBlendMode: "screen" }} />
            </div>
          </div>
        </Reveal>

        {/* Card F — structure */}
        <Reveal style={{ gridColumn: "span 4" }} delay={100}>
          <div style={{ ...cardBase, padding: 26, height: "100%", display: "flex", flexDirection: "column", gap: 18 }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#FFAA00", letterSpacing: "0.2em" }}>ENGINE 03 · IQ STRUCTURE</div>
            <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 21, fontWeight: 700, color: "var(--lp-ink)", margin: 0 }}>The map, labeled honestly</h3>
            <p style={{ ...bodyMuted, fontSize: 15 }}>
              Market structure, volumetric order blocks and liquidity sweeps, each labeled only
              when it confirms, at two tiers of significance.
            </p>
            <ChartPlaceholder label="CHoCH · BOS · OB · SWEEP" />
          </div>
        </Reveal>

      </div>
    </section>
  );
}


// ---------- AI stack ----------

/* ---------- Analyst chat demo: a scripted, looping conversation ----------
   The card is BLANK, the question types itself in, the analyst "thinks"
   (three dots), then the answer streams in line by line like a real chat.
   Holds, clears, second exchange, loops. Owner 2026-08-31: a typing thing,
   not blocks that appear and disappear. Product-sim: fixed dark colors. */

type ChatLine = { lead?: string; text: string };
type ChatExchange = { q: string; lines: ChatLine[]; facts: string[]; chips: string[] };

const CHAT_SCRIPT: ChatExchange[] = [
  {
    q: "Worth chasing this breakout?",
    lines: [
      { text: "The flip printed on hot volume: real participation, not drift." },
      { text: "Daily regime is 3 bars old, flow buying on both tiers. Weekly was already long." },
      { text: "Price sits 4% over the basis. Chasing here buys the stretch, not the trend." },
      { lead: "Bottom line:", text: "long side only. Starter here at most; the entry is the first basis retest." },
    ],
    facts: ["REGIME · BULL 3 BARS", "FLOW · BUYING BOTH TIERS", "STRETCH · +4% OVER BASIS"],
    chips: ["What invalidates it?", "Where is the trail now?", "Scan for similar setups"],
  },
  {
    q: "And where is the exit if it rolls over?",
    lines: [
      { text: "The daily basis is the tripwire. While price closes above it, the long is intact." },
      { text: "First warning comes earlier: fast-tier flow flipping to selling at the band edge." },
      { lead: "Bottom line:", text: "a daily close under the basis is the exit. The first red candle is not." },
    ],
    facts: ["TRIPWIRE · DAILY BASIS", "WATCH · FAST-TIER FLOW", "EXIT · DAILY CLOSE BELOW"],
    chips: ["Arm that alert", "Check the weekly read", "What size makes sense?"],
  },
];

/* per-phase timing, ms */
const CT = { blank: 700, qChar: 34, think: 450, dots: 1250, aChar: 13, linePause: 380, chips: 320, hold: 3600, fade: 450 };

type ChatMarks = {
  qStart: number; dotsStart: number; dotsEnd: number;
  lineStarts: number[]; chipsAt: number; holdEnd: number; end: number;
};

const CHAT_MARKS: ChatMarks[] = (() => {
  const out: ChatMarks[] = [];
  let t = 0;
  for (const ex of CHAT_SCRIPT) {
    const qStart = t + CT.blank;
    const qEnd = qStart + ex.q.length * CT.qChar;
    const dotsStart = qEnd + CT.think;
    const dotsEnd = dotsStart + CT.dots;
    const lineStarts: number[] = [];
    let lt = dotsEnd;
    for (const ln of ex.lines) {
      lineStarts.push(lt);
      lt += ((ln.lead ? ln.lead.length + 1 : 0) + ln.text.length) * CT.aChar + CT.linePause;
    }
    const chipsAt = lt + CT.chips;
    const holdEnd = chipsAt + CT.hold;
    const end = holdEnd + CT.fade;
    out.push({ qStart, dotsStart, dotsEnd, lineStarts, chipsAt, holdEnd, end });
    t = end;
  }
  return out;
})();
const CHAT_TOTAL = CHAT_MARKS[CHAT_MARKS.length - 1].end;

/* the analyst's mark: a steel monogram, used in the header and beside replies */
function AnalystMark({ size = 24 }: { size?: number }) {
  return (
    <span
      aria-hidden="true"
      style={{
        width: size, height: size, borderRadius: Math.round(size * 0.32), flex: "0 0 auto",
        background: "linear-gradient(135deg, #3D69A8 0%, #2A4C80 100%)",
        boxShadow: "0 0 0 1px rgba(140,163,197,.18) inset, 0 4px 12px rgba(61,105,168,.25)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600, fontSize: Math.round(size * 0.38), letterSpacing: ".02em", color: "#FFFFFF",
      }}
    >
      IQ
    </span>
  );
}

function AnalystChatDemo() {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const elapsed = useRef(0);
  const [, force] = useState(0);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setReduced(true);
      return;
    }
    const el = rootRef.current;
    if (!el) return;
    let timer: number | null = null;
    let last = 0;
    const start = () => {
      if (timer !== null) return;
      last = performance.now();
      timer = window.setInterval(() => {
        const now = performance.now();
        /* clamp so a throttled background tab resumes smoothly, no skips */
        elapsed.current = (elapsed.current + Math.min(now - last, 120)) % CHAT_TOTAL;
        last = now;
        force((v) => v + 1);
      }, 40);
    };
    const stop = () => { if (timer !== null) { window.clearInterval(timer); timer = null; } };
    const io = new IntersectionObserver((es) => es.forEach((e) => (e.isIntersecting ? start() : stop())), { threshold: 0.15 });
    io.observe(el);
    return () => { stop(); io.disconnect(); };
  }, []);

  const t = elapsed.current;
  let ex = 0;
  while (ex < CHAT_MARKS.length - 1 && t >= CHAT_MARKS[ex].end) ex++;
  const m = CHAT_MARKS[ex];
  const script = CHAT_SCRIPT[ex];

  /* reduced motion: the first exchange, complete and still */
  const done = reduced;
  const qChars = done ? CHAT_SCRIPT[0].q.length : Math.max(0, Math.floor((t - m.qStart) / CT.qChar));
  const showDots = !done && t >= m.dotsStart && t < m.dotsEnd;
  const fading = !done && t >= m.holdEnd;
  const view = done ? CHAT_SCRIPT[0] : script;
  const viewMarks = done ? CHAT_MARKS[0] : m;
  const answering = done || t >= viewMarks.lineStarts[0];
  const settled = done || t >= viewMarks.chipsAt;

  const MONO = "'IBM Plex Mono', monospace";

  return (
    <div ref={rootRef} style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 400 }}>
      <style>{`
        @keyframes lpCaret { 0%, 55% { opacity: 1; } 56%, 100% { opacity: 0; } }
        .lp-caret { display: inline-block; width: 7px; margin-left: 2px; background: #8CA3C5; height: 1em; vertical-align: text-bottom; border-radius: 1px; animation: lpCaret 0.9s steps(1) infinite; }
        @keyframes lpDot { 0%, 60%, 100% { opacity: .25; transform: none; } 30% { opacity: 1; transform: translateY(-3px); } }
        .lp-dot { width: 6px; height: 6px; border-radius: 50%; background: #8CA3C5; display: inline-block; animation: lpDot 1.1s ease infinite; }
        @keyframes lpChipIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
        .lp-chipin { animation: lpChipIn .4s ease both; }
      `}</style>

      {/* the transcript: this is the part that clears between exchanges */}
      <div style={{ padding: "18px 18px 6px", display: "flex", flexDirection: "column", gap: 14, flex: 1, fontSize: 13.5, lineHeight: 1.6, opacity: fading ? 0 : 1, transition: "opacity .45s ease" }}>
        {(done || qChars > 0) && (
          <div style={{ alignSelf: "flex-end", maxWidth: "78%", padding: "10px 14px", borderRadius: "16px 16px 4px 16px", background: "linear-gradient(135deg, #3D69A8 0%, #2F5A94 100%)", color: "#FFFFFF", boxShadow: "0 8px 22px rgba(61,105,168,.22)" }}>
            {view.q.slice(0, qChars)}
            {!done && qChars < view.q.length && <span className="lp-caret" style={{ background: "rgba(255,255,255,.85)" }} aria-hidden="true" />}
          </div>
        )}

        {(showDots || answering) && (
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10, maxWidth: "92%" }}>
            <AnalystMark size={22} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".12em", color: "#5C6E93", marginBottom: 6 }}>IQ ANALYST</div>
              <div style={{ background: "#151515", border: "1px solid rgba(255,255,255,.07)", borderRadius: "4px 16px 16px 16px", padding: showDots ? "12px 16px" : "12px 14px 12px 14px" }}>
                {showDots ? (
                  <div style={{ display: "inline-flex", gap: 5, alignItems: "center", height: 16 }} aria-label="The analyst is typing">
                    <span className="lp-dot" />
                    <span className="lp-dot" style={{ animationDelay: ".18s" }} />
                    <span className="lp-dot" style={{ animationDelay: ".36s" }} />
                  </div>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
                    {view.lines.map((ln, i) => {
                      const startAt = viewMarks.lineStarts[i];
                      if (!done && t < startAt) return null;
                      const full = (ln.lead ? ln.lead + " " : "") + ln.text;
                      const chars = done ? full.length : Math.max(0, Math.floor((t - startAt) / CT.aChar));
                      if (!done && chars <= 0) return null;
                      const visible = full.slice(0, chars);
                      const leadLen = ln.lead ? ln.lead.length : 0;
                      const typing = !done && chars < full.length;
                      if (ln.lead) {
                        return (
                          <div key={`${ex}-${i}`} style={{ marginTop: 4, paddingTop: 10, borderTop: "1px solid rgba(255,255,255,.07)", color: "#DCE4F0" }}>
                            <span style={{ color: "#F2F5FA", fontWeight: 600 }}>{visible.slice(0, leadLen)}</span>
                            {visible.slice(leadLen)}
                            {typing && <span className="lp-caret" aria-hidden="true" />}
                          </div>
                        );
                      }
                      return (
                        <div key={`${ex}-${i}`} style={{ display: "flex", gap: 10, color: "#C9D3E3" }}>
                          <span aria-hidden="true" style={{ width: 5, height: 5, borderRadius: "50%", background: "#3D69A8", flex: "0 0 auto", marginTop: 8 }} />
                          <span>
                            {visible}
                            {typing && <span className="lp-caret" aria-hidden="true" />}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* the evidence the read stands on: grounded in the live scan */}
              {settled && (
                <div className="lp-chipin" style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
                  {view.facts.map((f) => (
                    <span key={f} style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".08em", color: "#8CA3C5", background: "rgba(61,105,168,.12)", border: "1px solid rgba(61,105,168,.28)", borderRadius: 6, padding: "4px 8px" }}>
                      {f}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {settled && (
          <div className="lp-chipin" style={{ display: "flex", gap: 8, flexWrap: "wrap", paddingLeft: 32 }}>
            {view.chips.map((c) => (
              <span key={c} style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12.5, fontWeight: 500, color: "#B9C7E2", border: "1px solid rgba(255,255,255,.1)", background: "rgba(255,255,255,.03)", padding: "7px 12px", borderRadius: 999 }}>
                {c}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* composer: always present, so the card reads as a chat even when blank */}
      <div style={{ padding: "10px 14px 14px" }}>
        <div style={{ height: 44, borderRadius: 999, background: "#151515", border: "1px solid rgba(255,255,255,.08)", display: "flex", alignItems: "center", padding: "0 6px 0 16px", gap: 10 }}>
          <span style={{ flex: 1, fontSize: 13.5, color: "#5C6E93", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Ask about any ticker, setup or exit</span>
          <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".1em", color: "#3A4A6B", whiteSpace: "nowrap" }} className="hidden md:inline">NVDA · 1D</span>
          <span aria-hidden="true" style={{ width: 32, height: 32, borderRadius: "50%", background: "#3D69A8", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto", boxShadow: "0 4px 12px rgba(61,105,168,.35)" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 19V5M5 12l7-7 7 7" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </span>
        </div>
      </div>
    </div>
  );
}

function AiSection() {
  const modeCard = (tag: string, title: string, body: string, delay: number) => (
    <Reveal style={{ flex: 1, minWidth: 240 }} delay={delay}>
      <div style={{ ...cardBase, padding: 24, height: "100%", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#8CA3C5", letterSpacing: "0.2em" }}>{tag}</div>
        <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 19, fontWeight: 700, color: "var(--lp-ink)", margin: 0 }}>{title}</h3>
        <p style={{ ...bodyMuted, fontSize: 14.5 }}>{body}</p>
      </div>
    </Reveal>
  );

  return (
    <section style={{ ...wrap, paddingTop: 130, paddingBottom: 20 }}>
      <Reveal blur>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 40, flexWrap: "wrap" }}>
        <div>
          <div style={eyebrow("#8CA3C5")}>IQ ANALYST</div>
          <h2 style={h2Style}>
            The read,
            <br />
            when you ask for it.
          </h2>
        </div>
        <p style={{ ...bodyMuted, maxWidth: 400 }}>
          The IQ Analyst answers from the live engine states: regime, momentum, structure,
          confluence per timeframe. Not from vibes. Ask, and it quotes the evidence.
        </p>
      </div>
      </Reveal>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 18, marginTop: 52 }}>
        {/* chat mock — a looping animation: question lands, the read types
            in line by line, chips arrive; holds, fades, repeats. Product-sim
            card: fixed dark, constant colors in BOTH themes. */}
        <Reveal style={{ gridColumn: "span 7" }}>
          <div style={{ ...cardBase, background: "radial-gradient(70% 45% at 0% 0%, rgba(61,105,168,.12), transparent 70%) #0D0D0D", overflow: "hidden", height: "100%", display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,.08)" }}>
              <AnalystMark size={26} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13.5, fontWeight: 600, color: "#F2F5FA", lineHeight: 1.2 }}>IQ Analyst</div>
                <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, letterSpacing: ".12em", color: "#5C6E93", marginTop: 3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>NVDA · 1D · GROUNDED IN THE LIVE SCAN</div>
              </div>
              <span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 6, fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, letterSpacing: ".12em", color: "#8CA3C5", border: "1px solid rgba(61,105,168,.3)", background: "rgba(61,105,168,.1)", borderRadius: 999, padding: "5px 10px", whiteSpace: "nowrap" }}>
                <span aria-hidden="true" style={{ width: 6, height: 6, borderRadius: "50%", background: "#3D69A8", boxShadow: "0 0 8px rgba(61,105,168,.9)", animation: "iqScanPulse 1.6s ease-in-out infinite" }} />
                LIVE READ
              </span>
            </div>
            <style>{`@keyframes iqScanPulse { 0%,100% { opacity: 1; } 50% { opacity: .35; } }`}</style>
            <AnalystChatDemo />
          </div>
        </Reveal>

        {/* modes */}
        <Reveal style={{ gridColumn: "span 5" }} delay={60}>
          <div style={{ display: "flex", flexDirection: "column", gap: 18, height: "100%" }}>
            <div style={{ ...cardBase, padding: 24, display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#089981", letterSpacing: "0.2em" }}>ANALYSE</div>
              <p style={{ ...bodyMuted, fontSize: 14.5, margin: 0 }}>
                Any scanned ticker, explained from its current engine states, with a verdict, not a shrug.
              </p>
            </div>
            <div style={{ ...cardBase, padding: 24, display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#8CA3C5", letterSpacing: "0.2em" }}>PINE COPILOT</div>
              <p style={{ ...bodyMuted, fontSize: 14.5, margin: 0 }}>
                Describe an indicator and get working Pine v6 back, including companions that extend the IQ suite without exposing its source.
              </p>
            </div>
            <div style={{ ...cardBase, padding: 24, display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#FFAA00", letterSpacing: "0.2em" }}>TRADING COACH</div>
              <p style={{ ...bodyMuted, fontSize: 14.5, margin: 0 }}>
                Process, risk habits and psychology: the part nobody automates. Questions back, never trade calls.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// ---------- The show: product tiles ----------
/* One headline, one line, two text links, the product below. Tiles alternate
   white and grey, edge to edge, 12px gutters; only the indicators tile takes a
   mint tint. Panels follow the theme, so the light site shows light panels.
   Colour comes from the product itself. */
type TileTheme = "white" | "grey" | "mint";
function Tile({ theme, half = false, title, sub, links, children }: { theme: TileTheme; half?: boolean; title: string; sub: string; links: [string, string][]; children: React.ReactNode }) {
  return (
    <div className={`lp-tile lp-tile-${theme}`} style={{ position: "relative", overflow: "hidden", padding: half ? "60px 28px 56px" : "84px 32px 84px", textAlign: "center" }}>
      <Reveal>
      <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: half ? 38 : 56, fontWeight: 700, letterSpacing: "-.03em", lineHeight: 1.05, color: "var(--lp-ink)", margin: "0 auto", maxWidth: 820, whiteSpace: "pre-line" }}>{title}</h3>
      <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: half ? 18 : 23, lineHeight: 1.4, color: "var(--lp-body)", margin: "14px auto 0", maxWidth: 680 }}>{sub}</p>
      <div style={{ display: "flex", justifyContent: "center", gap: 30, marginTop: 18, flexWrap: "wrap" }}>
        {links.map(([label, href]) => (
          <a key={label} href={href} className="lp-tile-link" style={{ fontSize: half ? 17 : 19 }}>{label} ›</a>
        ))}
      </div>
      </Reveal>
      <Reveal delay={80}>
      <div style={{ maxWidth: half ? 640 : 980, margin: `${half ? 36 : 48}px auto 0`, textAlign: "left" }}>{children}</div>
      </Reveal>
    </div>
  );
}

function PaysSection() {
  return (
    <section id="pays" style={{ paddingTop: 96 }}>
      <style>{`
        .lp-tile-white { background: #FFFFFF; }
        [data-theme="dark"] .lp-tile-white { background: #141517; }
        .lp-tile-grey { background: #F5F5F7; }
        [data-theme="dark"] .lp-tile-grey { background: #1B1D21; }
        .lp-tile-mint { background: linear-gradient(180deg, #E6F6EF, #F3FBF7); }
        [data-theme="dark"] .lp-tile-mint { background: linear-gradient(180deg, #10201A, #121A16); }
        [data-theme="dark"] .lp-engines > div { background: rgba(255,255,255,.04) !important; }
        .lp-tiles-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px; }
        .lp-tile-link { text-decoration: none; font-weight: 500; font-family: 'DM Sans', sans-serif; color: #3D69A8; }
        [data-theme="dark"] .lp-tile-link { color: #8CA3C5; }
        .lp-tile-link:hover { text-decoration: underline; }
        ${DEMO_CSS}
        @media (max-width: 900px) { .lp-tiles-2 { grid-template-columns: 1fr; } }
      `}</style>

      <Tile theme="grey" title="Backtests TradingView won't run." sub="Sweeps, walk-forward, Monte Carlo, against buy-and-hold. You see what holds out of sample." links={[["Backtest an idea", "/signup"], ["Why walk-forward", "/guide/faqs"]]}>
        <BacktestDemo />
      </Tile>

      <div className="lp-tiles-2">
        <Tile half theme="white" title="Tell me it repaints before I trust it." sub="Every call audited. Two years replayed, zero mismatches." links={[["Run the audit", "/signup"], ["What repainting is", "/guide/faqs"]]}>
          <RepaintDemo />
        </Tile>
        <Tile half theme="white" title="Version history that isn't dreadful." sub="Every diff, every note, one-click rollback." links={[["Keep every version", "/signup"], ["How versions work", "/features"]]}>
          <VersionDemo compact />
        </Tile>
      </div>

      <div className="lp-tiles-2">
        <Tile half theme="grey" title="Run it across the watchlist. Now." sub="The live tape. Every name that fires, the minute it fires." links={[["Open the live tape", "/signup"], ["How the tape prints", "/guide/live-tape"]]}>
          <div className="lp-demo"><InferenceTerminal demo rows={9} /></div>
        </Tile>
        <Tile half theme="grey" title="Alerts straight into the broker." sub="Written, hosted, connected. Interactive Brokers and Alpaca." links={[["Route my alerts", "/signup"], ["How alerts route", "/guide/alerts"]]}>
          <BrokerDemo compact />
        </Tile>
      </div>

      <div style={{ marginTop: 12 }}>
        <Tile theme="mint" title="Locked on close. Never repainted." sub="Three engines, one verdict, on any TradingView chart." links={[["See the indicators", "/indicators"], ["How the engines agree", "/guide/iq-bands"]]}>
          <HeroWindow fluid />
          <div className="lp-engines" style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12, marginTop: 14 }}>
            <style>{`@media (max-width: 760px) { .lp-engines { grid-template-columns: 1fr !important; } }`}</style>
            {[["IQ Bands", "The regime, drawn on price. Flips only when the market changes character."], ["IQ Oscillator", "Momentum beneath it. Has to agree before anything fires."], ["IQ Structure", "The map: structure, order blocks and sweeps, labeled only when confirmed."]].map(([n, d]) => (
              <div key={n} style={{ padding: "16px 18px", borderRadius: 14, background: "rgba(255,255,255,.55)", border: hairline }}>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 15, fontWeight: 700, color: "var(--lp-ink)" }}>{n}</div>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13.5, lineHeight: 1.5, color: "var(--lp-body)", marginTop: 4 }}>{d}</div>
              </div>
            ))}
          </div>
        </Tile>
      </div>
    </section>
  );
}

// ---------- What we won't sell you ----------
function NotThisSection() {
  const items = ["A chat box that writes Pine", "A gallery of 50 classic indicators", "RSI, explained in plain English"];
  return (
    <div className="lp-tile lp-tile-grey" style={{ marginTop: 12, padding: "72px 32px", textAlign: "center" }}>
      <Reveal>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 38, fontWeight: 700, letterSpacing: "-.03em", lineHeight: 1.1, color: "var(--lp-ink)", margin: "0 auto", maxWidth: 760 }}>Not for sale here.</div>
      <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 18, lineHeight: 1.45, color: "var(--lp-body)", margin: "12px auto 0", maxWidth: 620 }}>If a general assistant does it equally well, it is not a product.</p>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center", marginTop: 22 }}>
        {items.map((t) => (
          <span key={t} style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 14, fontWeight: 600, color: "var(--lp-muted)", textDecoration: "line-through", textDecorationColor: "rgba(242,54,69,.6)", textDecorationThickness: 2, border: hairline, borderRadius: 999, padding: "9px 14px", background: "var(--lp-card)" }}>{t}</span>
        ))}
      </div>
      </Reveal>
    </div>
  );
}

// ---------- Platform ----------
function PlatformSection() {
  /* tiny product-sim strips (constants — dark in both themes) */
  const strip: React.CSSProperties = {
    background: "#0A0A0A",
    border: "1px solid rgba(255,255,255,.07)",
    borderRadius: 10,
    padding: "10px 12px",
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 10.5,
    letterSpacing: ".04em",
    display: "flex",
    flexDirection: "column",
    gap: 7,
  };
  const vRow = (l: string, m: string, r: string, rc: string) => (
    <div key={l + r} style={{ display: "flex", justifyContent: "space-between", gap: 10, whiteSpace: "nowrap", overflow: "hidden" }}>
      <span style={{ color: "#EAF1FC" }}>{l}</span>
      <span style={{ color: "#5C6E93", overflow: "hidden", textOverflow: "ellipsis" }}>{m}</span>
      <span style={{ color: rc }}>{r}</span>
    </div>
  );
  const VISUALS: Record<string, React.ReactNode> = {
    SCREENER: (
      <div style={strip}>
        {vRow("NVDA", "conf 4/4 · wave rising", "BULL · 18 bars", "#089981")}
        {vRow("TSLA", "conf 3/4 · flow buying", "BULL · 2 bars", "#089981")}
        {vRow("GOOGL", "conf 1/4 · wave falling", "BEAR · 5 bars", "#F23645")}
      </div>
    ),
    "TRIPLE SIGNALS": (
      <div style={strip}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          <span style={{ color: "#EAF1FC" }}>NVDA</span>
          <span style={{ color: "#089981" }}>LONG ·</span>
          {["30M", "2H", "1D"].map((c) => (
            <span key={c} style={{ border: "1px solid rgba(8,153,129,.4)", color: "#089981", borderRadius: 999, padding: "2px 8px" }}>{c} ▲</span>
          ))}
        </div>
        <div style={{ color: "#5C6E93" }}>all three clocks aligned — printed 14:30, locked on close</div>
      </div>
    ),
    "LIVE TAPE": (
      <div style={strip}>
        {vRow("14:32", "NVDA · INTRADAY", "BUY ▲ 219.61", "#089981")}
        {vRow("14:31", "TSLA · SWING", "BUY ▲ 402.30", "#089981")}
        {vRow("14:30", "META · INTRADAY", "SELL ▼ 812.33", "#F23645")}
      </div>
    ),
    "ALERTS & ALGOS": (
      <div style={strip}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#089981", display: "inline-block" }} />
          <span style={{ color: "#EAF1FC" }}>IQ ALERT · NVDA LONG LOCKED</span>
        </div>
        <div style={{ color: "#5C6E93" }}>push ✓ · email ✓ · webhook → bridge · 0.4s after close</div>
      </div>
    ),
  };
  const card = (tag: string, color: string, title: string, body: string, chips: string[], delay: number) => (
    <Reveal style={{ gridColumn: "span 6" }} delay={delay}>
      <div style={{ ...cardBase, padding: 26, height: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
        <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color, letterSpacing: "0.2em" }}>{tag}</div>
        <h3 style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 21, fontWeight: 700, color: "var(--lp-ink)", margin: 0 }}>{title}</h3>
        <p style={{ ...bodyMuted, fontSize: 15, flex: 1 }}>{body}</p>
        {VISUALS[tag]}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {chips.map((t) => (
            <span key={t} style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "#9DB2D4", border: hairline, padding: "6px 12px", borderRadius: 999 }}>
              {t}
            </span>
          ))}
        </div>
      </div>
    </Reveal>
  );

  return (
    <section style={{ ...wrap, paddingTop: 130, paddingBottom: 20 }}>
      <Reveal blur>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 40, flexWrap: "wrap" }}>
        <div>
          <div style={eyebrow("#089981")}>THE PLATFORM</div>
          <h2 style={h2Style}>
            Beyond
            <br />
            the chart.
          </h2>
        </div>
        <p style={{ ...bodyMuted, maxWidth: 400 }}>
          The engines feed a full desk: scanner, signals, tape and delivery. The read
          reaches you wherever you are.
        </p>
      </div>
      </Reveal>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 18, marginTop: 52 }}>
        {card(
          "SCREENER",
          "#8CA3C5",
          "Every ticker, ranked by the engines",
          "Filter roughly a thousand US names by regime, confluence, wave state, flow and structure on the daily, weekly or monthly clock, or pull only the fresh flips from the latest pass.",
          ["engine-state filters", "fresh flips", "3 clocks"],
          0,
        )}
        {card(
          "TRIPLE SIGNALS",
          "#089981",
          "Three clocks agree, or nothing prints",
          "A ticker lists only while the 30-minute, 2-hour and daily regimes align. No partial setups. A second intraday tier runs the same gate on 1, 5 and 15 minutes.",
          ["30m · 2H · 1D", "intraday tier", "no partial setups"],
          60,
        )}
        {card(
          "LIVE TAPE",
          "#FFAA00",
          "The market, streamed as it changes state",
          "Every regime flip, momentum turn and triple lock across the 25 most retail-traded names plus BTC and ETH, scanned every minute. A raw feed that churns with the session.",
          ["25 names + crypto", "1m · 5m · 15m", "updates every minute"],
          100,
        )}
        {card(
          "ALERTS & ALGOS",
          "#8CA3C5",
          "The read, delivered",
          "Push, email or webhook the moment a closed bar locks a signal. One dynamic stream covers every condition, ready to drive a broker bridge or a bot without you watching the screen.",
          ["push + email", "webhook-ready", "fires on close"],
          140,
        )}
      </div>
    </section>
  );
}

// ---------- Statement ----------
function Statement() {
  return (
    <section style={{ position: "relative", paddingTop: 150, textAlign: "center", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 60, left: "50%", transform: "translateX(-50%)", width: 900, height: 500, background: "radial-gradient(closest-side, rgba(61,105,168,.12), transparent 70%)", pointerEvents: "none" }} />
      <div style={{ ...wrap, position: "relative" }}>
        <Reveal blur>
        <div style={eyebrow("var(--lp-muted)")}>WHY IT WORKS</div>
        <h2
          style={{
            fontFamily: "'DM Sans', sans-serif",
            fontSize: "clamp(40px, 6vw, 72px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            lineHeight: 1.02,
            color: "var(--lp-ink)",
            maxWidth: 900,
            margin: "22px auto 0",
          }}
        >
          In at the flip.
          <br />
          Out at the target.
        </h2>
        <p style={{ ...bodyMuted, fontSize: 19, maxWidth: 560, margin: "26px auto 0" }}>
          The regime flips only when a close proves it. No repaints, no rewrites.
          Scroll back two years: the history you see is exactly what fired live.
        </p>
        </Reveal>
      </div>
    </section>
  );
}

// ---------- Stats ----------
function useCountUp(target: number, decimals = 0) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVal(target);
      return;
    }
    let started = false;
    const start = () => {
      if (started) return;
      started = true;
      const t0 = performance.now();
      const dur = 1400;
      const step = (t: number) => {
        const k = Math.min(1, (t - t0) / dur);
        const eased = 1 - Math.pow(1 - k, 3);
        setVal(parseFloat((target * eased).toFixed(decimals)));
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    const io = new IntersectionObserver((entries) => entries.forEach((e) => e.isIntersecting && start()), { threshold: 0.3 });
    io.observe(el);
    return () => io.disconnect();
  }, [target, decimals]);
  return { val, ref };
}

function StatCell({ target, decimals = 0, suffix = "", label, sub }: { target: number; decimals?: number; suffix?: string; label: string; sub: string }) {
  const { val, ref } = useCountUp(target, decimals);
  const display = decimals > 0 ? val.toFixed(decimals) : Math.round(val).toString();
  return (
    <div ref={ref} style={{ padding: "44px 32px", borderRight: hairline }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, fontVariantNumeric: "tabular-nums" }}>
        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 56, fontWeight: 800, letterSpacing: "-0.03em", color: "var(--lp-ink)" }}>{display}</span>
        {suffix && <span style={{ fontSize: 24, color: "#8CA3C5", fontWeight: 600 }}>{suffix}</span>}
      </div>
      <div style={{ marginTop: 10, color: "var(--lp-ink)", fontSize: 16, fontWeight: 600 }}>{label}</div>
      <div style={{ marginTop: 4, color: "var(--lp-body)", fontSize: 14 }}>{sub}</div>
    </div>
  );
}

function Stats() {
  return (
    <section id="proof" style={{ paddingTop: 120 }}>
      <Reveal>
      <div style={{ ...wrap, borderTop: hairline, borderBottom: hairline, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", padding: 0 }}>
        <StatCell target={3} label="Engines, one verdict" sub="regime · momentum · structure" />
        <StatCell target={980} suffix="+" label="Names in every scan" sub="daily · weekly · monthly" />
        <StatCell target={9} label="Clocks watched" sub="from 1 minute to monthly" />
        <StatCell target={27} label="On the live tape" sub="scanned every minute, live" />
      </div>
      </Reveal>
    </section>
  );
}

// ---------- Pricing ----------
const REAL_TIERS = [
  {
    name: "IQ Pro",
    monthly: 64.99,
    yearlyPerMo: 39.99,
    blurb: "The full market read: indicators, live scans, signals and the IQ Analyst.",
    features: [
      "IQ Bands + IQ Oscillator on TradingView",
      "Live dashboard, screeners and Triple Signals",
      "IQ Analyst: chart analysis chat",
      "One dynamic alert stream covers every condition",
    ],
    highlight: false,
  },
  {
    name: "IQ Plus",
    monthly: 114.99,
    yearlyPerMo: 59.99,
    blurb: "Everything in Pro, plus the builder's tier: structure, copilot and coaching.",
    features: [
      "Everything from IQ Pro",
      "IQ Structure, the price-action suite",
      "Pine Copilot + Trading Coach",
      "Expanded daily AI credits, early access",
    ],
    highlight: true,
  },
] as const;

function Pricing() {
  return (
    <section id="pricing" style={{ ...wrap, paddingTop: 140 }}>
      <Reveal blur>
      <div style={{ textAlign: "center" }}>
        <div style={eyebrow("#8CA3C5")}>PRICING</div>
        <h2 style={h2Style}>Two ways to pay.</h2>
        <p style={{ ...bodyMuted, fontSize: 18, maxWidth: 600, margin: "22px auto 0" }}>
          Per idea, or per month. Stripe checkout, cancel any time.
        </p>
      </div>
      </Reveal>

      <div
        className="iq-price-grid"
        style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 400px))", justifyContent: "center", gap: 20, marginTop: 52 }}
      >
        <Reveal>
          <div style={{ ...cardBase, padding: 30, height: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, letterSpacing: "0.2em", color: "var(--lp-muted)", textTransform: "uppercase" }}>Per idea</span>
              <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10.5, letterSpacing: "0.12em", padding: "4px 10px", borderRadius: 999, border: "1px solid rgba(61,105,168,.4)", color: "#8CA3C5", fontWeight: 600 }}>
                FOUNDING ACCESS
              </span>
            </div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
              <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 48, fontWeight: 800, letterSpacing: "-0.03em", color: "var(--lp-ink)", lineHeight: 1 }}>$49</span>
              <span style={{ color: "var(--lp-body)", fontSize: 15 }}>one-off, per idea</span>
            </div>
            <div style={{ color: "var(--lp-muted)", fontSize: 13.5, marginTop: -8 }}>no subscription attached</div>
            <p style={{ ...bodyMuted, fontSize: 14.5 }}>Describe one strategy once. Get the Pine for charting plus the checks and the report that TradingView will not give you.</p>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
              {["Compile-safe Pine v6 for the idea", "Repaint and lookahead check", "Backtest report: sweeps, out-of-sample, buy-and-hold", "Blunt verdict on what is fitted"].map((f) => (
                <li key={f} style={{ display: "flex", gap: 10, alignItems: "flex-start", color: "var(--lp-body)", fontSize: 14.5, lineHeight: 1.5 }}>
                  <span aria-hidden="true" style={{ color: "#089981", fontWeight: 700 }}>✓</span>
                  {f}
                </li>
              ))}
            </ul>
            <a
              href="/pricing"
              style={{ display: "inline-flex", justifyContent: "center", width: "100%", padding: "14px", borderRadius: 999, fontWeight: 700, fontSize: 15, textDecoration: "none", background: "rgba(255,255,255,.05)", color: "var(--lp-ink)", border: hairline }}
            >
              Reserve an idea slot →
            </a>
          </div>
        </Reveal>
        {REAL_TIERS.map((tier) => (
          <Reveal key={tier.name}>
            <div
              style={{
                ...cardBase,
                padding: 30,
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: 16,
                ...(tier.highlight
                  ? { borderColor: "rgba(61,105,168,.45)", background: "linear-gradient(170deg, rgba(61,105,168,.09), rgba(255,255,255,.015) 55%)" }
                  : {}),
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, letterSpacing: "0.2em", color: tier.highlight ? "#8CA3C5" : "var(--lp-muted)", textTransform: "uppercase" }}>
                  {tier.name}
                </span>
                {tier.highlight && (
                  <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10.5, letterSpacing: "0.12em", padding: "4px 10px", borderRadius: 999, background: "#3D69A8", color: "#fff", fontWeight: 700 }}>
                    MOST POPULAR
                  </span>
                )}
              </div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 48, fontWeight: 800, letterSpacing: "-0.03em", color: "var(--lp-ink)", lineHeight: 1 }}>
                  ${tier.yearlyPerMo}
                </span>
                <span style={{ color: "var(--lp-body)", fontSize: 15 }}>/mo billed yearly</span>
              </div>
              <div style={{ color: "var(--lp-muted)", fontSize: 13.5, marginTop: -8 }}>
                or ${tier.monthly}/mo billed monthly
              </div>
              <p style={{ ...bodyMuted, fontSize: 14.5 }}>{tier.blurb}</p>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                {tier.features.map((f) => (
                  <li key={f} style={{ display: "flex", gap: 10, alignItems: "flex-start", color: "var(--lp-body)", fontSize: 14.5, lineHeight: 1.5 }}>
                    <span aria-hidden="true" style={{ color: "#089981", fontWeight: 700 }}>✓</span>
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href="/pricing"
                style={{
                  display: "inline-flex",
                  justifyContent: "center",
                  width: "100%",
                  padding: "14px",
                  borderRadius: 999,
                  fontWeight: 700,
                  fontSize: 15,
                  textDecoration: "none",
                  ...(tier.highlight
                    ? { background: "#3D69A8", color: "#fff", boxShadow: "0 10px 36px rgba(61,105,168,.35)" }
                    : { background: "rgba(255,255,255,.05)", color: "var(--lp-ink)", border: hairline }),
                }}
              >
                Get {tier.name} →
              </a>
            </div>
          </Reveal>
        ))}
      </div>

      <p style={{ textAlign: "center", marginTop: 26, fontSize: 13, color: "var(--lp-muted)" }}>
        Full plan details on the <a href="/pricing" style={{ color: "#8CA3C5", textDecoration: "none" }}>pricing page</a>.
      </p>
      <style>{`
        @media (max-width: 1100px) { .iq-price-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; } }
        @media (max-width: 760px) { .iq-price-grid { grid-template-columns: 1fr !important; } }
      `}</style>
    </section>
  );
}

// ---------- FAQ ----------
const FAQS = [
  { q: "Does Alpha Charts repaint?", a: "No. Every signal locks the moment a bar closes, so your live chart matches your backtest exactly, with no signals shifting after the fact." },
  { q: "Which markets and timeframes does it work on?", a: "Any liquid market on TradingView: futures, equities, FX and crypto, on every timeframe from one minute to weekly." },
  { q: "Does the copilot's Pine actually compile?", a: "It is written in Pine v6 only, against the current language reference, and drawn on the workbench before you paste it, so you see the script work before TradingView does. A hard compile gate that runs every script through the Pine compiler before it reaches you is in build. Until it ships, the Pine editor stays the final word, and we say so." },
  { q: "How do I know an IQ signal does not repaint?", a: "Every signal is gated on the confirmed bar, higher-timeframe values come through security() with an offset and lookahead off, and nothing is drawn until the bar closes. Scroll two years back on any chart: the historical flips match what fired live in the alert log." },
  { q: "Do I need to know how to code?", a: "No. The indicators work out of the box, and the copilot writes the Pine when you want your own idea on the chart. You describe, it builds, you paste." },
  { q: "Do I need a paid TradingView plan?", a: "No. The indicators run on any TradingView plan, including Free. Alert limits follow your TradingView plan." },
  { q: "How do I get access after paying?", a: "At checkout you enter your TradingView username. We grant invite-only access to both scripts, usually within minutes and always within 24 hours, and they appear under Indicators → Invite-only scripts." },
  { q: "Can I cancel anytime?", a: "Yes. Monthly and annual plans cancel in one click, and every plan is covered by a seven-day money-back guarantee." },
];

function FAQ() {
  const [open, setOpen] = useState(0);
  return (
    <section id="faq" style={{ maxWidth: 780, margin: "0 auto", padding: "130px 32px 40px", textAlign: "center" }}>
      <div style={eyebrow("#8CA3C5")}>FAQ</div>
      <h2 style={{ ...h2Style, fontSize: 48, marginBottom: 40 }}>Questions, answered.</h2>
      <div style={{ textAlign: "left" }}>
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={i} style={{ borderTop: hairline }}>
              <button
                onClick={() => setOpen(isOpen ? -1 : i)}
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "space-between",
                  gap: 16,
                  padding: "24px 4px",
                  background: "transparent",
                  border: "none",
                  color: "var(--lp-ink)",
                  fontSize: 18,
                  fontWeight: 600,
                  textAlign: "left",
                  cursor: "pointer",
                  fontFamily: "inherit",
                }}
              >
                <span>{f.q}</span>
                <span style={{ fontSize: 24, fontWeight: 300, color: "#8CA3C5", lineHeight: 1 }}>{isOpen ? "–" : "+"}</span>
              </button>
              {isOpen && <div style={{ padding: "0 4px 26px", fontSize: 16, lineHeight: 1.62, color: "var(--lp-body)" }}>{f.a}</div>}
            </div>
          );
        })}
        <div style={{ borderTop: hairline }} />
      </div>
    </section>
  );
}

// ---------- Final CTA ----------
function FinalCTA() {
  return (
    <section style={{ position: "relative", marginTop: 140, borderTop: hairline, overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          left: "50%",
          bottom: -320,
          transform: "translateX(-50%)",
          width: 1300,
          height: 700,
          background: "radial-gradient(closest-side, rgba(61,105,168,.3), rgba(61,105,168,.06) 60%, transparent 75%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: "linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          WebkitMaskImage: "radial-gradient(70% 80% at 50% 100%, #000, transparent 80%)",
          maskImage: "radial-gradient(70% 80% at 50% 100%, #000, transparent 80%)",
          pointerEvents: "none",
        }}
      />
      <div style={{ ...wrap, position: "relative", padding: "130px 32px 120px", textAlign: "center" }}>
        <div style={eyebrow("#8CA3C5")}>GET THE EDGE</div>
        <h2
          style={{
            fontFamily: "'DM Sans', sans-serif",
            fontSize: "clamp(44px, 7vw, 74px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            lineHeight: 1,
            color: "var(--lp-ink)",
            margin: 0,
          }}
        >
          Stop guessing.
          <br />
          Trade confirmed.
        </h2>
        <p style={{ ...bodyMuted, fontSize: 19, maxWidth: 480, margin: "26px auto 0" }}>
          Add Alpha Charts to any chart in five minutes. No lock-in, cancel anytime.
        </p>
        <div style={{ marginTop: 34 }}>
          <a
            href="/signup"
            style={{
              ...btnPrimary,
              padding: "17px 34px",
              fontSize: 16.5,
              boxShadow: "0 0 0 1px rgba(255,255,255,.14) inset, 0 16px 48px rgba(61,105,168,.35), 0 0 90px rgba(61,105,168,.4)",
            }}
          >
            Get Alpha Charts →
          </a>
        </div>
        <div style={{ marginTop: 18, fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: "var(--lp-muted)" }}>
          $39/mo · cancel anytime · 0 repaints
        </div>
      </div>
    </section>
  );
}

// ---------- Page ----------
function LandingPage() {
  // Mobile browser chrome follows the landing theme (spec §1); the switch
  // keeps it in sync on toggle.
  useEffect(() => {
    const t = document.documentElement.getAttribute("data-theme");
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", t === "dark" ? "#000000" : "#FFFFFF");
  }, []);
  return (
    <div className="iq-landing" style={{ background: "var(--lp-page-wash)", color: "var(--lp-ink)", minHeight: "100vh" }}>
      <SiteNav landing />
      <Hero />
      <Ticker />
      <PaysSection />
      <NotThisSection />
      <Stats />
      <Pricing />
      <FAQ />
      <FinalCTA />
      <SiteFooter />
    </div>
  );
}
