import { useEffect, useRef, useState } from "react";

/* Product demos for the landing. Time-driven scenes on a shared clock, an
   IntersectionObserver so nothing runs off-screen, a reduced-motion fallback
   that shows the final frame. Surfaces follow the site theme: white panels
   on the light site, charcoal on the dark one (owner 2026-09-03: no dark
   islands on the white version). Colour comes from the product itself. */

export const MONO = "'IBM Plex Mono', monospace";
export const UP = "#089981", DOWN = "#F23645", STEEL = "#3D69A8", AMBER = "#FFAA00";
export const V = {
  bg: "var(--d-bg)", surface: "var(--d-surface)", line: "var(--d-line)", ink: "var(--d-ink)", muted: "var(--d-muted)",
  faint: "var(--d-faint)", ghost: "var(--d-ghost)", chip: "var(--d-chip)", upInk: "var(--d-up-ink)", downInk: "var(--d-down-ink)",
  kw: "var(--d-kw)", str: "var(--d-str)", num: "var(--d-num)",
};
export const DEMO_CSS = `
.lp-demo{--d-bg:#FFFFFF;--d-surface:#F6F7F9;--d-line:rgba(10,14,20,.10);--d-ink:#0A0D13;--d-muted:#3A4450;--d-faint:#6B7480;--d-ghost:#B5BCC6;--d-chip:rgba(10,14,20,.04);--d-up-ink:#0B7A62;--d-down-ink:#C1262E;--d-kw:#3D69A8;--d-str:#0F7A5A;--d-num:#B86E00;--d-shadow:0 30px 80px rgba(10,15,25,.10)}
[data-theme="dark"] .lp-demo{--d-bg:#101214;--d-surface:#171A1E;--d-line:rgba(255,255,255,.08);--d-ink:#EAF1FC;--d-muted:#9DB2D4;--d-faint:#5C6E93;--d-ghost:#2F3A4C;--d-chip:rgba(255,255,255,.03);--d-up-ink:#CFF5E8;--d-down-ink:#FFD7DB;--d-kw:#8CA3C5;--d-str:#5FB98B;--d-num:#FFAA00;--d-shadow:0 30px 80px rgba(0,0,0,.45)}
@keyframes lpSpin { to { transform: rotate(360deg); } }
`;

export function useLoop(total: number, enabled = true) {
  const ref = useRef<HTMLDivElement | null>(null);
  const elapsed = useRef(0);
  const [, force] = useState(0);
  const [still, setStill] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setStill(true); return; }
    const el = ref.current; if (!el) return;
    let timer: number | null = null; let last = 0;
    const start = () => { if (timer !== null) return; last = performance.now(); timer = window.setInterval(() => { const now = performance.now(); elapsed.current = (elapsed.current + Math.min(now - last, 120)) % total; last = now; force((v) => v + 1); }, 40); };
    const stop = () => { if (timer !== null) { window.clearInterval(timer); timer = null; } };
    const io = new IntersectionObserver((es) => es.forEach((e) => (e.isIntersecting ? start() : stop())), { threshold: 0.2 });
    io.observe(el);
    return () => { stop(); io.disconnect(); };
  }, [total, enabled]);
  const t = still ? total - 1 : elapsed.current;
  return { ref, t, still, fading: enabled && !still && t >= total - 450 };
}

export const seg = (t: number, a: number, b: number) => Math.max(0, Math.min(1, (t - a) / (b - a)));

const card = (bare = false, fading = false): React.CSSProperties => ({
  background: bare ? "transparent" : V.bg, border: bare ? "none" : `1px solid ${V.line}`, borderRadius: bare ? 0 : 16, overflow: "hidden",
  boxShadow: bare ? "none" : "var(--d-shadow)", color: V.ink, fontFamily: MONO, fontSize: 12, lineHeight: 1.6, position: "relative",
  opacity: fading ? 0 : 1, transition: "opacity .4s ease",
});
/* a slim pane label for demos that live inside a larger window */
const slim: React.CSSProperties = { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, padding: "12px 18px 0", fontSize: 10, letterSpacing: ".14em", color: V.faint };
const bar: React.CSSProperties = { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, padding: "11px 16px", borderBottom: `1px solid ${V.line}`, fontSize: 10, letterSpacing: ".14em", color: V.faint };

function Dot({ c }: { c: string }) { return <span style={{ width: 6, height: 6, borderRadius: "50%", background: c, display: "inline-block", boxShadow: `0 0 8px ${c}` }} />; }
function Caret() { return <span style={{ display: "inline-block", width: 6, height: "1em", background: V.kw, verticalAlign: "text-bottom", marginLeft: 1 }} />; }

/* ---------------- Repaint audit: every call verified ---------------- */
const RP_LINES = [
  "//@version=6",
  'indicator("Breakout v5")',
  "htf = request.security(syminfo.tickerid, \"D\", close[1], lookahead=barmerge.lookahead_off)",
  "fast = ta.ema(close, 9)",
  "long = barstate.isconfirmed and ta.crossover(fast, htf)",
  "plotshape(long, style=shape.triangleup)",
  "alertcondition(long, \"Long\")",
];
const RP_OK = [
  { line: 2, tag: "HIGHER TIMEFRAME", why: "close[1] with lookahead off. Nothing from the future." },
  { line: 4, tag: "ENTRY GATE", why: "barstate.isconfirmed. Fires once, on the close." },
  { line: 6, tag: "ALERT", why: "Same condition as the plot. No divergence." },
];
export function RepaintDemo() {
  const T = 9000; const { ref, t, fading } = useLoop(T);
  const scan = seg(t, 300, 3400);
  const rowAt = Math.floor(scan * RP_LINES.length);
  const verified = t >= 4200;
  const replayed = t >= 5400;
  return (
    <div ref={ref} className="lp-demo" style={card(false, fading)}>
      <style>{DEMO_CSS}</style>
      <div style={bar}><span>REPAINT AUDIT · BREAKOUT_V5.PINE</span><span style={{ color: verified ? UP : V.muted }}>{verified ? "● VERIFIED" : "● AUDITING"}</span></div>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.3fr) minmax(220px,1fr)" }}>
        <div style={{ padding: "14px 16px", position: "relative", minHeight: 210 }}>
          {RP_LINES.map((ln, i) => {
            const ok = RP_OK.some((x) => x.line === i) && rowAt > i;
            return (
              <div key={i} style={{ display: "flex", gap: 12, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", background: ok ? "rgba(8,153,129,.10)" : "transparent", borderLeft: `2px solid ${ok ? UP : "transparent"}`, paddingLeft: 8, marginLeft: -10, transition: "background .3s" }}>
                <span style={{ color: V.ghost, width: 14, textAlign: "right", flex: "0 0 auto" }}>{i + 1}</span>
                <span style={{ color: ok ? V.upInk : V.muted, overflow: "hidden", textOverflow: "ellipsis" }}>{ln}</span>
              </div>
            );
          })}
          {t < 3400 && <div style={{ position: "absolute", left: 0, right: 0, top: 14 + scan * 168, height: 22, background: "linear-gradient(180deg, transparent, rgba(8,153,129,.22), transparent)", pointerEvents: "none" }} />}
        </div>
        <div style={{ borderLeft: `1px solid ${V.line}`, background: V.surface, padding: "14px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontSize: 10, letterSpacing: ".14em", color: V.faint }}>VERIFIED</div>
          {RP_OK.map((x) => {
            const show = rowAt > x.line;
            if (!show) return <div key={x.line} style={{ height: 52, borderRadius: 10, border: `1px dashed ${V.line}` }} />;
            return (
              <div key={x.line} style={{ padding: "9px 11px", borderRadius: 10, border: "1px solid rgba(8,153,129,.35)", background: "rgba(8,153,129,.08)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8, fontSize: 10.5, letterSpacing: ".1em", color: UP }}><span>✓ {x.tag}</span><span style={{ color: V.faint }}>L{x.line + 1}</span></div>
                <div style={{ fontSize: 11, color: V.muted, marginTop: 3 }}>{x.why}</div>
              </div>
            );
          })}
          <div style={{ marginTop: "auto", paddingTop: 10, borderTop: `1px solid ${V.line}`, display: "flex", flexDirection: "column", gap: 4 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: verified ? UP : V.faint, letterSpacing: ".08em" }}><Dot c={verified ? UP : STEEL} />{verified ? "NO REPAINT · HISTORY = LIVE" : "READING EVERY CALL"}</div>
            <div style={{ fontSize: 10.5, color: replayed ? V.muted : V.ghost, letterSpacing: ".06em", transition: "color .4s" }}>{replayed ? "2 years replayed bar by bar · 0 mismatches" : "replaying history against the live log"}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Backtest with sweeps ---------------- */
const EQ = (() => { let v = 100, w = 100; const s: number[] = [], b: number[] = []; for (let i = 0; i < 80; i++) { const shock = Math.sin(i * 1.7) * 1.4 + Math.cos(i * 0.31) * 0.9; v += 1.15 + shock; w += 0.55 + Math.sin(i * 0.9) * 1.1; s.push(v); b.push(w); } return { s, b }; })();
const SWEEP = [0.74, 0.88, 1.02, 1.21, 1.46, 1.58, 1.64, 1.71, 1.66, 1.52, 1.31, 1.12];
const PLATEAU = [4, 5, 6, 7, 8, 9];
export function BacktestDemo() {
  const T = 11000; const { ref, t, fading } = useLoop(T);
  const draw = seg(t, 200, 3200);
  const n = seg(t, 400, 2600);
  const sweep = seg(t, 3400, 6400); const cur = Math.floor(sweep * SWEEP.length);
  const verdict = t >= 7200;
  const W = 420, H = 130;
  const toPath = (arr: number[]) => arr.map((y, i) => `${(i / (arr.length - 1)) * W},${H - ((y - 90) / 120) * H}`).join(" ");
  const stat = (label: string, val: string, c = V.ink) => (
    <div style={{ padding: "10px 12px", borderRadius: 10, background: V.chip, border: `1px solid ${V.line}` }}>
      <div style={{ fontSize: 9.5, letterSpacing: ".14em", color: V.faint }}>{label}</div>
      <div style={{ fontSize: 17, fontWeight: 600, color: c, marginTop: 2, fontVariantNumeric: "tabular-nums" }}>{val}</div>
    </div>
  );
  return (
    <div ref={ref} className="lp-demo" style={card(false, fading)}>
      <style>{DEMO_CSS}</style>
      <div style={bar}><span>BACKTEST · SQUEEZE BREAKOUT · NQ 5M · 2019 TO 2026</span><span style={{ color: verdict ? UP : V.muted }}>{verdict ? "● ROBUST" : "WALK-FORWARD · 7 FOLDS"}</span></div>
      <div style={{ padding: 16, display: "grid", gridTemplateColumns: "repeat(4, minmax(0,1fr))", gap: 8 }}>
        {stat("NET PROFIT", `+${(64.7 * n).toFixed(1)}%`, UP)}
        {stat("WIN RATE", `${(58.2 * n).toFixed(1)}%`)}
        {stat("PROFIT FACTOR", (1.64 * n).toFixed(2))}
        {stat("MAX DRAWDOWN", `-${(6.8 * n).toFixed(1)}%`, DOWN)}
      </div>
      <div style={{ padding: "0 16px 12px" }}>
        <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="130" preserveAspectRatio="none" style={{ display: "block" }}>
          {[0.25, 0.5, 0.75].map((g) => <line key={g} x1="0" x2={W} y1={H * g} y2={H * g} stroke={V.line} />)}
          <polyline points={toPath(EQ.b)} fill="none" stroke={DOWN} strokeWidth="1.4" opacity={0.8} pathLength={1} style={{ strokeDasharray: "1", strokeDashoffset: 1 - draw }} />
          <polyline points={toPath(EQ.s)} fill="none" stroke={UP} strokeWidth="2" pathLength={1} style={{ strokeDasharray: "1", strokeDashoffset: 1 - draw, filter: "drop-shadow(0 0 6px rgba(8,153,129,.5))" }} />
        </svg>
        <div style={{ display: "flex", gap: 14, fontSize: 10, letterSpacing: ".1em", color: V.faint, marginTop: 4 }}><span style={{ color: UP }}>— STRATEGY</span><span style={{ color: DOWN }}>— BUY AND HOLD</span></div>
      </div>
      <div style={{ padding: "12px 16px 16px", borderTop: `1px solid ${V.line}`, background: V.surface }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, letterSpacing: ".14em", color: V.faint }}><span>PARAMETER SWEEP · LENGTH 10 TO 32</span><span>{sweep > 0 ? `${Math.min(cur + 1, SWEEP.length)}/12 RUNS` : ""}</span></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 4, marginTop: 8 }}>
          {SWEEP.map((f, i) => { const on = i < cur || sweep >= 1; const solid = verdict && PLATEAU.includes(i); return <div key={i} style={{ height: 26, borderRadius: 5, background: on ? `rgba(8,153,129,${0.12 + (f / 2) * 0.6})` : V.chip, border: `1px solid ${solid ? UP : i === cur && sweep < 1 ? STEEL : V.line}`, boxShadow: solid ? "0 0 10px rgba(8,153,129,.35)" : "none", transition: "background .3s, box-shadow .3s" }} />; })}
        </div>
        <div style={{ marginTop: 10, minHeight: 34, display: "flex", alignItems: "center", gap: 10, fontSize: 11.5, color: verdict ? V.upInk : V.faint, transition: "color .4s" }}>
          <Dot c={verdict ? UP : STEEL} />
          {verdict ? "Holds out of sample: beat buy-and-hold in 6 of 7 walk-forward years. Length 24 sits on a plateau, 18 to 28 all profitable." : "Optimising on 2019 to 2023, testing on 2024 to 2026"}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Alerts into a broker ---------------- */
const PAYLOAD = '{ "ticker": "NVDA", "side": "long", "tf": "1D", "price": 217.55, "reason": "triple lock", "bar": "closed" }';
export function BrokerDemo({ compact = false }: { compact?: boolean }) {
  const T = 9000; const { ref, t, fading } = useLoop(T);
  const typed = PAYLOAD.slice(0, Math.floor(seg(t, 300, 2600) * PAYLOAD.length));
  const stages = [
    { at: 3000, label: "WEBHOOK", val: "received · 0.2s after close" },
    { at: 4300, label: "INTERACTIVE BROKERS", val: "order accepted · 100 @ MKT" },
    { at: 5600, label: "ALPACA", val: "filled · 217.60" },
  ];
  return (
    <div ref={ref} className="lp-demo" style={card(false, fading)}>
      <style>{DEMO_CSS}</style>
      <div style={bar}><span>ALERT → BROKER · NVDA LONG LOCKED</span><span style={{ color: t >= 5600 ? UP : V.muted }}>{t >= 5600 ? "● EXECUTED" : t >= 3000 ? "● ROUTING" : "● WRITING ALERT"}</span></div>
      <div style={{ display: "grid", gridTemplateColumns: compact ? "1fr" : "minmax(0,1.2fr) 40px minmax(0,1fr)", alignItems: "stretch" }}>
        <div style={{ padding: "16px", borderRight: compact ? "none" : `1px solid ${V.line}`, borderBottom: compact ? `1px solid ${V.line}` : "none" }}>
          <div style={{ fontSize: 10, letterSpacing: ".14em", color: V.faint, marginBottom: 8 }}>ALERT JSON · WRITTEN FOR YOU</div>
          <div style={{ color: V.ink, whiteSpace: "pre-wrap", wordBreak: "break-word", minHeight: 96 }}>{typed}{typed.length < PAYLOAD.length && <Caret />}</div>
        </div>
        {!compact && <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: t >= 3000 ? STEEL : V.ghost, fontSize: 18, transition: "color .3s" }}>→</span>
        </div>}
        <div style={{ padding: "16px", display: "flex", flexDirection: "column", gap: 8, background: V.surface }}>
          {stages.map((s) => { const on = t >= s.at; return (
            <div key={s.label} style={{ padding: "9px 11px", borderRadius: 10, border: `1px solid ${on ? "rgba(8,153,129,.4)" : V.line}`, background: on ? "rgba(8,153,129,.08)" : V.chip, transition: "all .3s" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 10.5, letterSpacing: ".1em", color: on ? UP : V.faint }}><Dot c={on ? UP : V.ghost} />{s.label}</div>
              <div style={{ fontSize: 11, color: on ? V.upInk : V.ghost, marginTop: 3 }}>{on ? s.val : "waiting"}</div>
            </div>
          ); })}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Version history ---------------- */
const DIFF = [
  { k: " ", s: "long = barstate.isconfirmed and ta.crossover(fast, htf)" },
  { k: " ", s: "plotshape(long, style=shape.triangleup)" },
  { k: "+", s: "inSession = not na(time(timeframe.period, \"0930-1600\"))" },
  { k: "+", s: "long := long and inSession" },
  { k: "+", s: "alertcondition(long, \"Long\", \"{{ticker}} long on close\")" },
  { k: "+", s: "// v5: session filter, alert routed to Alpaca on the closed bar" },
];
const VERSIONS = ["v5 · session filter, Alpaca alerts", "v4 · daily trend filter", "v3 · squeeze release logic", "v2 · targets and trailing stop", "v1 · first paste"];
export function VersionDemo({ compact = false }: { compact?: boolean }) {
  const T = 8500; const { ref, t, fading } = useLoop(T);
  const shown = Math.floor(seg(t, 300, 3800) * DIFF.length);
  const saved = t >= 4600;
  return (
    <div ref={ref} className="lp-demo" style={card(false, fading)}>
      <style>{DEMO_CSS}</style>
      <div style={bar}><span>VERSIONS · BREAKOUT.PINE</span><span style={{ color: saved ? UP : V.muted }}>{saved ? "● v5 SAVED · 4 LINES ADDED" : "● v4 → v5"}</span></div>
      <div style={{ display: "grid", gridTemplateColumns: compact ? "1fr" : "minmax(0,1.4fr) minmax(200px,1fr)" }}>
        <div style={{ padding: "14px 16px", minHeight: compact ? 150 : 200 }}>
          {DIFF.slice(0, shown).map((d, i) => (
            <div key={i} style={{ display: "flex", gap: 10, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", background: d.k === "+" ? "rgba(8,153,129,.10)" : d.k === "-" ? "rgba(242,54,69,.10)" : "transparent", padding: "1px 6px", margin: "0 -6px", borderRadius: 4 }}>
              <span style={{ color: d.k === "+" ? UP : d.k === "-" ? DOWN : V.ghost, width: 10 }}>{d.k}</span>
              <span style={{ color: d.k === "+" ? V.upInk : d.k === "-" ? V.downInk : V.muted, textDecoration: d.k === "-" ? "line-through" : "none", overflow: "hidden", textOverflow: "ellipsis" }}>{d.s}</span>
            </div>
          ))}
          {shown < DIFF.length && <Caret />}
        </div>
        <div style={{ borderLeft: compact ? "none" : `1px solid ${V.line}`, borderTop: compact ? `1px solid ${V.line}` : "none", background: V.surface, padding: "14px 16px", display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ fontSize: 10, letterSpacing: ".14em", color: V.faint, marginBottom: 4 }}>HISTORY</div>
          {VERSIONS.map((v, i) => { const isNew = i === 0; const vis = !isNew || saved; return (
            <div key={v} style={{ padding: "7px 10px", borderRadius: 8, fontSize: 11, color: isNew ? V.ink : V.muted, background: isNew && saved ? "rgba(61,105,168,.14)" : V.chip, border: `1px solid ${isNew && saved ? "rgba(61,105,168,.45)" : V.line}`, opacity: vis ? 1 : 0.35, transition: "all .35s" }}>{v}</div>
          ); })}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Blueprint: three questions → blueprint → script ----------------
   Our own name for the guided start (not the competitor's). Drives itself, or
   takes an external clock when it is one half of the creator window. */
type BStep = { q: string; opts: string[]; pick: number[]; multi?: boolean; at: number; picksAt: number[]; goAt: number };
const BSTEPS: BStep[] = [
  { q: "What should the next tool do with the squeeze breakout?", opts: ["Turn releases into multi-symbol setups", "Rank breakouts by conviction", "Audit which breakouts fail, and why", "Map the squeeze zones on the chart", "Fire alerts on the closed-bar release", "My own idea…"], pick: [2], at: 0, picksAt: [1500], goAt: 2500 },
  { q: "Which failure matters most after entry?", opts: ["Immediate recross of the band", "Opposing flip on the higher timeframe", "Slow decay without a target", "Cap filter let an extended entry through", "My own idea…"], pick: [1], at: 3100, picksAt: [4500], goAt: 5500 },
  { q: "What should the audit track?", opts: ["Approved versus cap-blocked entries", "Bars to validation", "Failure type per trade", "Would-have-been result of blocked entries", "My own idea…"], pick: [0, 2, 3], multi: true, at: 6100, picksAt: [6900, 7500, 8100], goAt: 8900 },
];
export const BLUEPRINT_SPEC_AT = 9400;
/* the answers picked so far, for the script pane to list as requirements */
export function blueprintPicks(t: number): string[] {
  const out: string[] = [];
  for (const st of BSTEPS) st.pick.forEach((pi, k) => { if (t >= st.picksAt[k]) out.push(st.opts[pi]); });
  return out;
}
const SPEC = [
  { k: "BLUEPRINT", v: "Squeeze Failure Atlas", type: true },
  { k: "PROBLEM", v: "Squeeze breakouts look clean and fail fast. A win rate hides which ones failed, and why.", type: true },
  { k: "LOGIC", v: "1  Confirmed release on the closed bar   2  Cap filter before entry   3  Track to target, invalidation or opposing flip" },
  { k: "THE TWIST", v: "A two-sided audit: what the filter blocked, and what it should have." },
  { k: "REPAINT RISK", v: "None. Confirmed bars only, higher timeframe via close[1], lookahead off.", green: true },
];
export function BlueprintDemo({ clock, bare = false }: { clock?: number; bare?: boolean }) {
  const T = 15600; const loop = useLoop(T, clock === undefined); const t = clock ?? loop.t;
  const fading = clock === undefined && loop.fading;
  const inSpec = t >= BLUEPRINT_SPEC_AT;
  const step = inSpec ? null : [...BSTEPS].reverse().find((s) => t >= s.at) ?? BSTEPS[0];
  const stepIdx = step ? BSTEPS.indexOf(step) : 3;
  const sans = "'DM Sans', sans-serif";
  return (
    <div ref={loop.ref} className="lp-demo" style={{ ...card(bare, fading), minHeight: 380 }}>
      <style>{DEMO_CSS}</style>
      <div style={bare ? slim : bar}><span>{bare ? "BLUEPRINT" : "PINE COPILOT · BLUEPRINT"}</span><span style={{ color: inSpec ? UP : V.muted }}>{inSpec ? "● READY" : `● ${stepIdx + 1} OF 3`}</span></div>
      {!inSpec && step && (
        <div style={{ padding: "18px 18px 16px" }}>
          <div style={{ fontFamily: sans, fontSize: 16, fontWeight: 600, color: V.ink, lineHeight: 1.35, marginBottom: 12 }}>{step.q}{step.multi && <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".12em", color: V.faint, marginLeft: 10 }}>PICK ANY</span>}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {step.opts.map((o, i) => {
              const pi = step.pick.indexOf(i);
              const on = pi >= 0 && t >= step.picksAt[pi];
              const other = i === step.opts.length - 1;
              return (
                <div key={o} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 12px", borderRadius: 10, border: `1px solid ${on ? "rgba(61,105,168,.6)" : V.line}`, background: on ? "rgba(61,105,168,.12)" : V.chip, transition: "all .25s" }}>
                  <span style={{ width: 22, height: 22, borderRadius: 6, border: `1px solid ${on ? STEEL : V.line}`, background: on ? (step.multi ? UP : STEEL) : "transparent", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: on ? "#FFFFFF" : V.muted, flex: "0 0 auto" }}>{on && step.multi ? "✓" : String.fromCharCode(65 + i)}</span>
                  <span style={{ fontFamily: sans, fontSize: 14, color: other ? V.faint : V.ink }}>{o}</span>
                </div>
              );
            })}
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 14, marginTop: 14 }}>
            <span style={{ fontFamily: sans, fontSize: 13, color: V.faint }}>Skip</span>
            <span style={{ fontFamily: sans, fontSize: 13.5, fontWeight: 600, color: t >= step.goAt ? "#FFFFFF" : V.muted, background: t >= step.goAt ? STEEL : V.chip, border: `1px solid ${t >= step.goAt ? STEEL : V.line}`, borderRadius: 999, padding: "9px 16px", transition: "all .2s" }}>{step.multi ? "Draw the blueprint" : "Next"} ↵</span>
          </div>
        </div>
      )}
      {inSpec && (
        <div style={{ padding: "18px 18px 16px", display: "flex", flexDirection: "column", gap: 12 }}>
          {SPEC.map((sec, i) => {
            const at = BLUEPRINT_SPEC_AT + 300 + i * 720;
            if (t < at) return null;
            const chars = sec.type ? Math.floor(seg(t, at, at + 650) * sec.v.length) : sec.v.length;
            return (
              <div key={sec.k} style={{ display: "grid", gridTemplateColumns: "104px 1fr", gap: 12, alignItems: "baseline" }}>
                <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: sec.green ? UP : V.faint }}>{sec.k}</span>
                <span style={{ fontFamily: sans, fontSize: i === 0 ? 18 : 13.5, fontWeight: i === 0 ? 700 : 400, color: sec.green ? V.upInk : i === 0 ? V.ink : V.muted, lineHeight: 1.5 }}>{sec.v.slice(0, chars)}{sec.type && chars < sec.v.length && <Caret />}</span>
              </div>
            );
          })}
          {t >= BLUEPRINT_SPEC_AT + 300 + SPEC.length * 720 + 300 && (
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", paddingTop: 12, borderTop: `1px solid ${V.line}`, marginTop: 4 }}>
              {["WRITE THE SCRIPT →", "RUN THE REPAINT AUDIT", "BACKTEST IT", "SET THE ALERTS"].map((c, i) => (
                <span key={c} style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: ".1em", color: i === 0 ? "#FFFFFF" : V.muted, background: i === 0 ? STEEL : V.chip, border: `1px solid ${i === 0 ? STEEL : V.line}`, borderRadius: 999, padding: "7px 12px" }}>{c}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
