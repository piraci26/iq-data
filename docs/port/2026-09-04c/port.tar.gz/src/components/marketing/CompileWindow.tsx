import { useLoop, seg, DEMO_CSS, V, UP, STEEL, MONO } from "@/components/marketing/Demos";

/* The script pane: Pine v6 types in clean, six pre-paste checks run and pass,
   the verdict lands. No failure beat. Follows the site theme. Drives itself
   or takes an external clock when it is the right half of the creator. */

const LINES = [
  "//@version=6",
  'indicator("Squeeze Failure Atlas", overlay=true)',
  "",
  'len   = input.int(20, "Length", minval=5)',
  'mult  = input.float(2.0, "Bands", step=0.1)',
  "",
  "basis = ta.sma(close, len)",
  "dev   = mult * ta.stdev(close, len)",
  "upper = basis + dev",
  "lower = basis - dev",
  "squeeze = (upper - lower) < 3 * ta.atr(len)",
  "",
  "// higher timeframe filter: yesterday's close, no lookahead",
  'htf = request.security(syminfo.tickerid, "D", close[1], lookahead=barmerge.lookahead_off)',
  "",
  "fired = barstate.isconfirmed and squeeze[1] and ta.crossover(close, upper) and close > htf",
  "",
  'plot(basis, "Basis", color.new(#3D69A8, 0))',
  'plotshape(fired, "Breakout", shape.triangleup, location.belowbar, color.new(#089981, 0))',
  'alertcondition(fired, "Squeeze breakout", "Breakout on {{ticker}} at {{close}}")',
];
const KEYWORDS = new Set(["indicator", "strategy", "plot", "plotshape", "alertcondition", "and", "or", "not", "if", "else", "var", "true", "false", "overlay"]);
const NS = ["ta.", "input.", "request.", "barstate.", "syminfo.", "color.", "shape.", "location.", "barmerge.", "math.", "str."];
function tokens(line: string) {
  const out: { t: string; c: string }[] = [];
  const re = /("[^"]*"|\/\/.*$|#[0-9A-Fa-f]{6}\b|\b\d+(?:\.\d+)?\b|\b[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)*\b|\s+|.)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(line)) !== null) {
    const t = m[0]; let c = V.ink;
    if (t.startsWith("//")) c = V.faint;
    else if (t.startsWith('"')) c = V.str;
    else if (/^#[0-9A-Fa-f]{6}$/.test(t) || /^\d/.test(t)) c = V.num;
    else if (KEYWORDS.has(t) || NS.some((n) => t.startsWith(n))) c = V.kw;
    out.push({ t, c });
  }
  return out;
}
const CHECKS = [
  ["Pine version", "v6 only"],
  ["request.security", "args in order · lookahead off"],
  ["series vs simple", "types resolve"],
  ["Deprecated calls", "none"],
  ["Bar logic", "confirmed bars only"],
  ["Peeks forward", "no"],
] as const;

export function CompileWindow({ embedded = false, bare = false, clock, notes = [] }: { embedded?: boolean; bare?: boolean; clock?: number; notes?: string[] }) {
  const T = 11000; const loop = useLoop(T, clock === undefined); const t = clock ?? loop.t;
  const SHOW = embedded ? LINES.slice(0, 11) : LINES;
  const typedLines = Math.floor(seg(t, 200, 3000) * SHOW.length);
  const checksFrom = 3300, per = 440;
  const done = t >= checksFrom + CHECKS.length * per + 300;
  const fading = clock === undefined && t >= T - 450;
  const waiting = t < 0;
  return (
    <div
      ref={loop.ref}
      className="lp-demo"
      style={{ width: bare ? "100%" : embedded ? "100%" : "min(980px, calc(100vw - 32px))", margin: bare || embedded ? 0 : "0 auto", background: bare ? "transparent" : V.bg, border: bare ? "none" : `1px solid ${V.line}`, borderRadius: bare ? 0 : 16, overflow: "hidden", boxShadow: bare ? "none" : "var(--d-shadow)", textAlign: "left", pointerEvents: "none", userSelect: "none", opacity: fading ? 0 : 1, transition: "opacity .4s ease", height: bare ? "100%" : undefined, display: bare ? "flex" : undefined, flexDirection: bare ? "column" : undefined }}
    >
      <style>{DEMO_CSS}</style>
      <style>{`
        .lp-cw-grid { display: grid; grid-template-columns: minmax(0, 1.45fr) minmax(240px, 1fr); flex: 1; }
        .lp-cw-grid.embedded { grid-template-columns: 1fr; }
        .lp-cw-grid.embedded .lp-cw-checks { border-left: none !important; border-top: 1px solid var(--d-line); display: grid !important; grid-template-columns: 1fr 1fr; gap: 8px; }
        .lp-cw-grid.embedded .lp-cw-verdict { grid-column: 1 / -1; margin-top: 2px !important; }
        @media (max-width: 860px) { .lp-cw-grid { grid-template-columns: 1fr; } .lp-cw-checks { border-left: none !important; border-top: 1px solid var(--d-line); } }
      `}</style>
      <div style={bare ? { display: "flex", alignItems: "center", gap: 8, padding: "12px 18px 0" } : { display: "flex", alignItems: "center", gap: 8, padding: "11px 16px", borderBottom: `1px solid ${V.line}` }}>
        <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: V.faint, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{bare ? "SCRIPT · PINE V6" : "SCRIPT · SQUEEZE_FAILURE_ATLAS.PINE · V6"}</span>
        <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", whiteSpace: "nowrap", color: done ? UP : V.muted }}>
          {done ? "● PASTES CLEAN" : t >= checksFrom ? "● CHECKING" : waiting ? "● LISTENING" : "● WRITING"}
        </span>
      </div>

      <div className={`lp-cw-grid${embedded ? " embedded" : ""}`}>
        <div style={{ padding: "16px 18px 16px 14px", fontFamily: MONO, fontSize: 12, lineHeight: 1.7, overflow: "hidden", minHeight: embedded ? 0 : 400, position: "relative" }}>
          {SHOW.slice(0, typedLines).map((ln, i) => (
            <div key={i} style={{ display: "flex", gap: 14, whiteSpace: "pre", overflow: "hidden" }}>
              <span style={{ width: 22, textAlign: "right", color: V.ghost, flex: "0 0 auto", fontSize: 11 }}>{i + 1}</span>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                {tokens(ln).map((tk, j) => <span key={j} style={{ color: tk.c }}>{tk.t}</span>)}
              </span>
            </div>
          ))}
          {typedLines < SHOW.length && !waiting && <span style={{ display: "inline-block", width: 7, height: 14, background: V.kw, marginLeft: 44, verticalAlign: "middle" }} />}
          {waiting && (
            <div style={{ padding: "2px 0 0 4px", display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: V.faint }}>FROM THE BLUEPRINT</div>
              {notes.length === 0 && <div style={{ fontFamily: MONO, fontSize: 11, color: V.ghost }}>requirements arrive as you answer</div>}
              {notes.map((n) => (
                <div key={n} style={{ display: "flex", gap: 10, alignItems: "flex-start", fontFamily: "'DM Sans', sans-serif", fontSize: 13.5, color: V.ink, lineHeight: 1.45 }}>
                  <span style={{ color: STEEL, fontFamily: MONO, fontSize: 12, marginTop: 1 }}>→</span><span>{n}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lp-cw-checks" style={{ borderLeft: `1px solid ${V.line}`, background: V.surface, padding: "18px 18px 20px", display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: V.faint, marginBottom: 4, gridColumn: "1 / -1" }}>CHECKS · BEFORE YOU PASTE</div>
          {CHECKS.map(([label, value], i) => {
            const startAt = checksFrom + i * per; const running = t >= startAt && t < startAt + per * 0.8; const passed = t >= startAt + per * 0.8;
            return (
              <div key={label} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "9px 11px", borderRadius: 10, background: passed ? "rgba(8,153,129,.08)" : V.chip, border: `1px solid ${passed ? "rgba(8,153,129,.35)" : V.line}`, opacity: t >= startAt ? 1 : 0.45, transition: "all .3s" }}>
                <span aria-hidden="true" style={{ width: 16, height: 16, borderRadius: "50%", flex: "0 0 auto", marginTop: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", border: `1px solid ${passed ? "rgba(8,153,129,.6)" : running ? STEEL : V.line}`, borderTopColor: running ? "transparent" : undefined, background: passed ? "rgba(8,153,129,.18)" : "transparent", animation: running ? "lpSpin .7s linear infinite" : "none" }}>
                  {passed && <svg width="9" height="9" viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2l2.3 2.3 4.7-5" stroke="#089981" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                </span>
                <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
                  <span style={{ fontFamily: MONO, fontSize: 11.5, color: V.ink }}>{label}</span>
                  <span style={{ fontFamily: MONO, fontSize: 10.5, color: passed ? V.muted : V.ghost }}>{passed ? value : running ? "checking" : "queued"}</span>
                </span>
              </div>
            );
          })}
          <div className="lp-cw-verdict" style={{ marginTop: "auto", paddingTop: 14, borderTop: `1px solid ${V.line}`, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, opacity: done ? 1 : 0.45, transition: "opacity .4s" }}>
            <span style={{ display: "flex", flexDirection: "column", gap: 3 }}>
              <span style={{ fontFamily: MONO, fontSize: 13, fontWeight: 600, letterSpacing: ".08em", color: done ? UP : V.faint }}>{done ? "PASTES CLEAN" : "RUNNING CHECKS"}</span>
              <span style={{ fontFamily: MONO, fontSize: 10.5, color: V.faint }}>{done ? "0 errors · 0 warnings" : t >= checksFrom ? "running 6 checks" : "writing pine v6"}</span>
            </span>
            <span style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: ".1em", color: "#FFFFFF", background: STEEL, borderRadius: 999, padding: "8px 12px", whiteSpace: "nowrap", boxShadow: done ? "0 0 0 6px rgba(61,105,168,.18), 0 6px 18px rgba(61,105,168,.4)" : "none", transition: "box-shadow .4s" }}>COPY TO TRADINGVIEW</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CompileWindow;
