import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { barsDailyQuery } from "@/lib/tht-api";
import { buildIqChart } from "@/components/iq/iqChartRender";

/* The hero's product window — a macOS-style app window, ALWAYS pure black
   in both themes, showing THE ACTUAL PRODUCT (owner decision 2026-08-31,
   superseding the spec's minimal SVG): the real IQ Bands + IQ Oscillator
   render on live NVDA daily bars, the exact builder the Screener and
   Signals desks use. Read-only; the window is the hero's single image. */

const MONO = "'IBM Plex Mono', monospace";

export function HeroWindow({ fluid = false }: { fluid?: boolean }) {
  const bars = useQuery(barsDailyQuery("NVDA"));
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    const data = bars.data;
    if (!el || !data || data.length < 45) return;
    return buildIqChart(el, data, { visibleBars: 150 });
  }, [bars.data]);

  return (
    <div
      className="lp-hero-window"
      style={{
        width: fluid ? "100%" : "min(980px, calc(100vw - 32px))",
        margin: fluid ? 0 : "0 auto",
        background: "#000000",
        border: "1px solid var(--lp-window-border)",
        borderRadius: 16,
        overflow: "hidden",
        boxShadow: "var(--lp-window-shadow)",
        textAlign: "left",
      }}
    >
      <style>{`
        /* a still picture of the product: no pan/zoom/crosshair, and no
           attribution logo inside this one marketing shot (the app pages
           keep it; the footer carries the TradingView notice) */
        .lp-hero-window a[href*="tradingview"] { display: none !important; }
      `}</style>
      {/* title bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,.07)" }}>
        <span aria-hidden="true" style={{ display: "inline-flex", gap: 8 }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FF5F57", display: "inline-block" }} />
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FEBC2E", display: "inline-block" }} />
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#28C840", display: "inline-block" }} />
        </span>
        <span style={{ marginLeft: 10, fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: "#5C6E93", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          IQ CORE · NVDA · 1D · IQ BANDS
        </span>
        <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 10, letterSpacing: ".14em", color: "#8CA3C5", whiteSpace: "nowrap" }}>
          ● LIVE
        </span>
      </div>
      {/* the real product render on live daily bars, identical in both themes */}
      <div
        role="img"
        aria-label="IQ Bands and the IQ Oscillator on NVDA, daily — the live product chart"
        style={{ height: 430, position: "relative" }}
      >
        {(!bars.data || bars.data.length < 45) && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: MONO, fontSize: 10.5, letterSpacing: ".14em", color: "#5C6E93" }}>
            {bars.isError ? "FEED UNREACHABLE" : "LOADING NVDA · DAILY…"}
          </div>
        )}
        <div ref={ref} style={{ position: "absolute", inset: 0, pointerEvents: "none" }} />
      </div>
    </div>
  );
}

export default HeroWindow;
