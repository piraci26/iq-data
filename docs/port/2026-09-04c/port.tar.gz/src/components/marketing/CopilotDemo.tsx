import { useLoop, seg, DEMO_CSS, V, UP, DOWN, STEEL, MONO } from "@/components/marketing/Demos";

/* The hero image is the real product: the IQ Analyst page in Pine mode.
   Left, the chat column exactly as it renders — the copilot asks for a
   direction (lettered cards), then the rules (a checklist with defaults and
   one-click build), then hands over the script. Right, the workbench: the
   CHART / CODE toggle, the symbol, the timeframe pills, clean candles, and
   the script drawn over them once it is built. One clock, one loop. */

const SANS = "'DM Sans', sans-serif";
const NEUTRAL = "#8595B4", BB_UP = "#36A845", BB_DN = "#D11D17";

/* ---- timeline (ms) ---- */
const T_ASK = 200, T_ASK_END = 1400;       // user types the idea
const T_DOTS1 = 1500, T_PHASE1 = 2500;      // copilot asks for a direction
const T_PICK = 4400, T_PICK_SENT = 5000;    // user picks a card
const T_DOTS2 = 5200, T_PHASE2 = 6200;      // copilot lists the rules
const T_BUILD = 8200, T_BUILD_SENT = 8700;  // build with defaults
const T_DOTS3 = 8900, T_SCRIPT = 9900;      // the script lands
const T_CODE_END = 12200, T_FLIP = 12600, T_DRAW_END = 14400;
const T_TOTAL = 21000;

const IDEA = "squeeze breakout on NVDA, no lookahead";
const PICKS = ["Close above the upper band, on a closed bar", "First candle back inside after a squeeze", "Band width at a 20-bar low", "Volume above average on the break"];
const RULES: [string, string][] = [["Length", "20"], ["Band width", "2.0"], ["Squeeze threshold", "1.5 × ATR"], ["Higher-timeframe filter", "daily"], ["Alert", "on"]];
const SCRIPT = [
  "//@version=6",
  'indicator("Squeeze Breakout", overlay=true)',
  'len   = input.int(20, "Length")',
  'mult  = input.float(2.0, "Band width")',
  "basis = ta.sma(close, len)",
  "dev   = mult * ta.stdev(close, len)",
  "upper = basis + dev",
  "lower = basis - dev",
  "squeeze = (upper - lower) < 1.5 * ta.atr(len)",
  'htf = request.security(syminfo.tickerid, "D", close[1], lookahead=barmerge.lookahead_off)',
  "fired = barstate.isconfirmed and squeeze[1] and ta.crossover(close, upper) and close > htf",
  'plot(basis, "Basis", color.new(#8595B4, 0))',
  'plot(upper, "Upper", color.new(#36A845, 0))',
  'plot(lower, "Lower", color.new(#D11D17, 0))',
  'plotshape(fired, "Breakout", shape.triangleup, location.belowbar, color.new(#089981, 0))',
  'alertcondition(fired, "Squeeze breakout", "Breakout on {{ticker}}")',
];
const KW = new Set(["indicator", "plot", "plotshape", "alertcondition", "and", "or", "not", "overlay", "true", "false"]);
const NS = ["ta.", "input.", "request.", "barstate.", "syminfo.", "color.", "shape.", "location.", "barmerge."];
function tokens(line: string) {
  const out: { t: string; c: string }[] = [];
  const re = /("[^"]*"|\/\/.*$|#[0-9A-Fa-f]{6}\b|\b\d+(?:\.\d+)?\b|\b[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)*\b|\s+|.)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(line)) !== null) {
    const t = m[0]; let c = V.ink;
    if (t.startsWith("//")) c = V.faint; else if (t.startsWith('"')) c = V.str; else if (/^#[0-9A-Fa-f]{6}$/.test(t) || /^\d/.test(t)) c = V.num; else if (KW.has(t) || NS.some((n) => t.startsWith(n))) c = V.kw;
    out.push({ t, c });
  }
  return out;
}

/* ---- synthetic 1-minute bars: a quiet squeeze, then the break ---- */
type Bar = { o: number; h: number; l: number; c: number };
const BARS: Bar[] = (() => {
  let seed = 7; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 - 0.5; };
  const out: Bar[] = []; let px = 217.4;
  for (let i = 0; i < 72; i++) {
    const vol = i < 26 ? 0.55 : i < 58 ? 0.16 : 0.5;
    const drift = i >= 58 && i < 66 ? 0.32 : 0;
    const o = px; const c = px + rnd() * vol * 2 + drift;
    const h = Math.max(o, c) + Math.abs(rnd()) * vol; const l = Math.min(o, c) - Math.abs(rnd()) * vol;
    out.push({ o, h, l, c }); px = c;
  }
  return out;
})();
const LEN = 20, MULT = 2.0;
const BB = (() => {
  const basis: (number | null)[] = [], up: (number | null)[] = [], dn: (number | null)[] = [];
  for (let i = 0; i < BARS.length; i++) {
    if (i < LEN - 1) { basis.push(null); up.push(null); dn.push(null); continue; }
    const w = BARS.slice(i - LEN + 1, i + 1).map((b) => b.c);
    const m = w.reduce((a, b) => a + b, 0) / LEN;
    const sd = Math.sqrt(w.reduce((a, b) => a + (b - m) * (b - m), 0) / LEN);
    basis.push(m); up.push(m + MULT * sd); dn.push(m - MULT * sd);
  }
  return { basis, up, dn };
})();
const BREAK_AT = (() => { for (let i = 58; i < BARS.length; i++) { const u = BB.up[i - 1]; if (u != null && BARS[i - 1].c <= u && BARS[i].c > (BB.up[i] ?? Infinity)) return i; } return 63; })();

function Chart({ draw }: { draw: number }) {
  const W = 620, H = 300, PAD_R = 46, PAD_B = 22;
  const lo = Math.min(...BARS.map((b) => b.l)) - 0.3, hi = Math.max(...BARS.map((b) => b.h)) + 0.3;
  const x = (i: number) => 10 + (i / (BARS.length - 1)) * (W - PAD_R - 20);
  const y = (p: number) => 8 + (1 - (p - lo) / (hi - lo)) * (H - PAD_B - 16);
  const n = Math.floor(draw * BARS.length);
  const path = (arr: (number | null)[]) => arr.slice(0, n).map((v, i) => (v == null ? null : `${i === LEN - 1 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`)).filter(Boolean).join(" ");
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((k) => lo + (hi - lo) * k);
  const cw = ((W - PAD_R - 20) / BARS.length) * 0.62;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" preserveAspectRatio="none" style={{ display: "block" }}>
      {ticks.map((p) => <line key={p} x1={0} x2={W - PAD_R} y1={y(p)} y2={y(p)} stroke={V.line} strokeWidth="1" />)}
      {ticks.map((p) => <text key={"t" + p} x={W - PAD_R + 6} y={y(p) + 3} fontFamily={MONO} fontSize="9" fill={V.faint}>{p.toFixed(2)}</text>)}
      {[0, 18, 36, 54, 71].map((i) => <text key={"x" + i} x={x(i)} y={H - 6} fontFamily={MONO} fontSize="9" fill={V.faint} textAnchor="middle">{`${9 + Math.floor((31 + i) / 60)}:${String((31 + i) % 60).padStart(2, "0")}`}</text>)}
      {BARS.map((b, i) => { const up = b.c >= b.o; const col = up ? UP : DOWN; return (
        <g key={i}>
          <line x1={x(i)} x2={x(i)} y1={y(b.h)} y2={y(b.l)} stroke={col} strokeWidth="1" />
          <rect x={x(i) - cw / 2} y={y(Math.max(b.o, b.c))} width={cw} height={Math.max(1, Math.abs(y(b.o) - y(b.c)))} fill={col} />
        </g>
      ); })}
      {n > LEN && (
        <g>
          <path d={path(BB.basis)} fill="none" stroke={NEUTRAL} strokeWidth="1.3" />
          <path d={path(BB.up)} fill="none" stroke={BB_UP} strokeWidth="1.3" />
          <path d={path(BB.dn)} fill="none" stroke={BB_DN} strokeWidth="1.3" />
          {n > BREAK_AT && <path d={`M${x(BREAK_AT) - 5},${y(BARS[BREAK_AT].l) + 12} L${x(BREAK_AT) + 5},${y(BARS[BREAK_AT].l) + 12} L${x(BREAK_AT)},${y(BARS[BREAK_AT].l) + 4} Z`} fill={UP} />}
        </g>
      )}
    </svg>
  );
}

/* ---- chat pieces, styled like the analyst page ---- */
function Tag() { return <div style={{ fontFamily: MONO, fontSize: 9.5, letterSpacing: ".14em", color: V.kw, marginBottom: 6 }}>IQ PINE COPILOT</div>; }
function Ai({ children, chips }: { children: React.ReactNode; chips?: string[] }) {
  return (
    <div style={{ maxWidth: "88%", alignSelf: "flex-start" }}>
      <Tag />
      <div style={{ background: V.surface, border: `1px solid ${V.line}`, borderRadius: "16px 16px 16px 4px", padding: "11px 14px", fontFamily: SANS, fontSize: 13.5, lineHeight: 1.55, color: V.ink }}>
        {children}
        {chips && <div style={{ display: "flex", gap: 6, marginTop: 8 }}>{chips.map((c) => <span key={c} style={{ fontFamily: MONO, fontSize: 9, letterSpacing: ".08em", color: V.faint, border: `1px solid ${V.line}`, borderRadius: 999, padding: "3px 9px" }}>{c}</span>)}</div>}
      </div>
    </div>
  );
}
function User({ text, caret }: { text: string; caret?: boolean }) {
  return <div style={{ alignSelf: "flex-end", maxWidth: "80%", background: STEEL, color: "#fff", borderRadius: "16px 16px 4px 16px", padding: "10px 14px", fontFamily: SANS, fontSize: 13.5, lineHeight: 1.5 }}>{text}{caret && <span style={{ display: "inline-block", width: 6, height: "1em", background: "rgba(255,255,255,.85)", verticalAlign: "text-bottom", marginLeft: 2 }} />}</div>;
}
function Dots() {
  return (
    <div style={{ alignSelf: "flex-start", background: V.surface, border: `1px solid ${V.line}`, borderRadius: "16px 16px 16px 4px", padding: "12px 16px", display: "inline-flex", gap: 5 }}>
      {[0, 1, 2].map((i) => <span key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: V.faint, animation: `lpDot 1.1s ease ${i * 0.18}s infinite` }} />)}
    </div>
  );
}
const row = (on = false): React.CSSProperties => ({ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 10, border: `1px solid ${on ? "rgba(61,105,168,.6)" : V.line}`, background: on ? "rgba(61,105,168,.12)" : V.chip, fontFamily: SANS, fontSize: 13, color: V.ink, transition: "all .2s" });
const badge: React.CSSProperties = { width: 20, height: 20, borderRadius: 6, border: `1px solid ${V.line}`, display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: MONO, fontSize: 10, color: V.muted, flex: "0 0 auto" };

export function CopilotDemo({ clock }: { clock?: number } = {}) {
  const loop = useLoop(T_TOTAL, clock === undefined);
  const ref = loop.ref; const t = clock ?? loop.t; const fading = clock === undefined && loop.fading;
  const idea = IDEA.slice(0, Math.floor(seg(t, T_ASK, T_ASK_END) * IDEA.length));
  const view: "chart" | "code" = t >= T_SCRIPT && t < T_FLIP ? "code" : "chart";
  const built = t >= T_FLIP;
  const codeLines = Math.floor(seg(t, T_SCRIPT, T_CODE_END) * SCRIPT.length);
  const draw = built ? seg(t, T_FLIP + 200, T_DRAW_END) : 0;
  const segStyle = (on: boolean): React.CSSProperties => ({ borderRadius: 999, border: `1px solid ${on ? "rgba(61,105,168,.3)" : "transparent"}`, background: on ? "rgba(61,105,168,.08)" : "transparent", padding: "3px 10px", fontFamily: MONO, fontSize: 9, letterSpacing: ".1em", color: on ? V.ink : V.faint });
  const tabs = ["DASHBOARD", "IQ ANALYST", "SCREENER", "SIGNALS", "LIVE TAPE", "INDICATORS"];
  return (
    <div ref={ref} className="lp-demo lp-hero-window" style={{ width: "min(1040px, calc(100vw - 32px))", margin: "0 auto", background: V.bg, border: `1px solid ${V.line}`, borderRadius: 18, overflow: "hidden", boxShadow: "var(--lp-window-shadow)", textAlign: "left", pointerEvents: "none", userSelect: "none", opacity: fading ? 0 : 1, transition: "opacity .4s ease" }}>
      <style>{DEMO_CSS}</style>
      <style>{`
        @keyframes lpDot { 0%, 60%, 100% { opacity: .25; transform: none; } 30% { opacity: 1; transform: translateY(-3px); } }
        .lp-cp { display: grid; grid-template-columns: minmax(0, 2fr) minmax(0, 3fr); height: 500px; }
        @media (max-width: 900px) { .lp-cp { grid-template-columns: 1fr; height: auto; } .lp-cp-bench { display: none !important; } }
      `}</style>
      {/* app chrome: the shell's nav and tab strip, in miniature */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 16px", borderBottom: `1px solid ${V.line}` }}>
        <span aria-hidden="true" style={{ display: "inline-flex", gap: 8 }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FF5F57", display: "inline-block" }} />
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FEBC2E", display: "inline-block" }} />
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#28C840", display: "inline-block" }} />
        </span>
        <span style={{ marginLeft: 10, fontFamily: SANS, fontSize: 12, fontWeight: 700, color: V.ink }}>Alpha Charts</span>
        <span style={{ marginLeft: "auto", fontFamily: MONO, fontSize: 9.5, letterSpacing: ".14em", color: built ? UP : V.faint }}>{built ? "● SCRIPT ON THE CHART" : t >= T_SCRIPT ? "● SCRIPT READY" : "● PINE COPILOT"}</span>
      </div>
      <div style={{ display: "flex", gap: 18, padding: "0 16px", borderBottom: `1px solid ${V.line}` }}>
        {tabs.map((tb) => <span key={tb} style={{ fontFamily: MONO, fontSize: 9, letterSpacing: ".14em", padding: "9px 0", color: tb === "IQ ANALYST" ? V.ink : V.faint, borderBottom: `2px solid ${tb === "IQ ANALYST" ? STEEL : "transparent"}` }}>{tb}</span>)}
      </div>

      <div className="lp-cp">
        {/* chat column */}
        <div style={{ borderRight: `1px solid ${V.line}`, display: "flex", flexDirection: "column", minHeight: 0 }}>
          <div style={{ flex: 1, minHeight: 0, overflow: "hidden", display: "flex", flexDirection: "column", justifyContent: "flex-end", gap: 12, padding: "16px 16px 10px", maskImage: "linear-gradient(180deg, transparent 0, #000 56px)", WebkitMaskImage: "linear-gradient(180deg, transparent 0, #000 56px)" }}>
            {t >= T_ASK && <User text={idea} caret={t < T_ASK_END} />}
            {t >= T_DOTS1 && t < T_PHASE1 && <Dots />}
            {t >= T_PHASE1 && (
              <Ai>
                <div>What should it fire on?</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, marginTop: 8 }}>
                  {PICKS.map((p, i) => <div key={p} style={row(i === 0 && t >= T_PICK)}><span style={{ ...badge, ...(i === 0 && t >= T_PICK ? { background: STEEL, color: "#fff", border: `1px solid ${STEEL}` } : {}) }}>{String.fromCharCode(65 + i)}</span>{p}</div>)}
                  <div style={{ ...row(), color: V.faint }}><span style={badge}>E</span>Something else…</div>
                </div>
              </Ai>
            )}
            {t >= T_PICK_SENT && <User text={PICKS[0]} />}
            {t >= T_DOTS2 && t < T_PHASE2 && <Dots />}
            {t >= T_PHASE2 && (
              <Ai>
                <div>A squeeze breakout on NVDA, confirmed on close. Set the rules:</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, marginTop: 8 }}>
                  {RULES.map(([k, d], i) => <div key={k} style={{ ...row(), justifyContent: "space-between" }}><span style={{ display: "flex", alignItems: "center", gap: 10 }}><span style={badge}>{i + 1}</span>{k}</span><span style={{ fontFamily: MONO, fontSize: 10.5, color: V.kw }}>{d}</span></div>)}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                  <span style={{ fontFamily: SANS, fontSize: 12.5, fontWeight: 600, color: "#fff", background: STEEL, borderRadius: 999, padding: "8px 14px", boxShadow: t >= T_BUILD && t < T_BUILD_SENT ? "0 0 0 5px rgba(61,105,168,.2)" : "none", transition: "box-shadow .2s" }}>Build with defaults ↵</span>
                  <span style={{ fontFamily: SANS, fontSize: 12, color: V.faint }}>or type the numbers you want changed</span>
                </div>
              </Ai>
            )}
            {t >= T_BUILD_SENT && <User text="Defaults are fine, build it" />}
            {t >= T_DOTS3 && t < T_SCRIPT && <Dots />}
            {t >= T_SCRIPT && <Ai chips={["PINE V6 · SCRIPT READY"]}>Here is the script. It fires only on the closed bar, with the daily filter from yesterday's close.</Ai>}
          </div>
          <div style={{ margin: "0 12px 12px", border: `1px solid ${V.line}`, borderRadius: 14, background: V.surface, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ flex: 1, fontFamily: SANS, fontSize: 13, color: V.faint }}>Describe the indicator or alert…</span>
            <span aria-hidden="true" style={{ width: 26, height: 26, borderRadius: "50%", background: STEEL, display: "inline-flex", alignItems: "center", justifyContent: "center" }}><svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 19V5M5 12l7-7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
          </div>
        </div>

        {/* workbench */}
        <div className="lp-cp-bench" style={{ display: "flex", flexDirection: "column", minHeight: 0, background: V.bg }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, padding: "9px 14px", borderBottom: `1px solid ${V.line}` }}>
            <div style={{ display: "inline-flex", gap: 4, border: `1px solid ${V.line}`, borderRadius: 999, padding: 3 }}>
              <span style={segStyle(view === "chart")}>CHART</span>
              <span style={segStyle(view === "code")}>CODE</span>
            </div>
            {view === "chart" ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ width: 70, textAlign: "center", borderRadius: 999, border: `1px solid ${V.line}`, background: V.surface, padding: "3px 10px", fontFamily: MONO, fontSize: 10.5, letterSpacing: ".06em", color: V.ink }}>NVDA</span>
                <div style={{ display: "inline-flex", gap: 2 }}>{(["1MIN", "D", "W", "M"] as const).map((tf) => <span key={tf} style={segStyle(tf === "1MIN")}>{tf}</span>)}</div>
              </div>
            ) : (
              <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: ".1em", color: V.kw, border: `1px solid rgba(61,105,168,.4)`, background: "rgba(61,105,168,.08)", borderRadius: 999, padding: "4px 10px" }}>COPY SCRIPT</span>
            )}
          </div>
          {view === "chart" ? (
            <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column", padding: "10px 10px 0" }}>
              <div style={{ flex: 1, minHeight: 0 }}><Chart draw={draw} /></div>
              <div style={{ padding: "8px 6px 9px", fontFamily: MONO, fontSize: 8.5, letterSpacing: ".1em", color: V.ghost, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {built ? "NVDA · 1-MINUTE · YOUR SCRIPT · APPROXIMATE PREVIEW — EXACT RENDER IN TRADINGVIEW" : "NVDA · 1-MINUTE · CLEAN CHART — YOUR INDICATOR PREVIEWS HERE ONCE BUILT"}
              </div>
            </div>
          ) : (
            <pre style={{ flex: 1, minHeight: 0, margin: 0, padding: "12px 16px", overflow: "hidden", fontFamily: MONO, fontSize: 10.5, lineHeight: 1.6, whiteSpace: "pre" }}>
              {SCRIPT.slice(0, codeLines).map((ln, i) => <div key={i}>{tokens(ln).map((tk, j) => <span key={j} style={{ color: tk.c }}>{tk.t}</span>)}</div>)}
              {codeLines < SCRIPT.length && <span style={{ display: "inline-block", width: 6, height: 12, background: V.kw, verticalAlign: "middle" }} />}
            </pre>
          )}
          <div style={{ padding: "8px 16px", borderTop: `1px solid ${V.line}`, fontFamily: MONO, fontSize: 8.5, letterSpacing: ".1em", color: V.ghost }}>PASTE INTO THE TRADINGVIEW PINE EDITOR · YOUR CODE STAYS YOURS</div>
        </div>
      </div>
    </div>
  );
}

export default CopilotDemo;
