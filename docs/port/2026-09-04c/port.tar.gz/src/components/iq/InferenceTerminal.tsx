import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { iqSignalsQuery, iqSwingSignalsQuery } from "@/lib/tht-api";

/* The live tape — SIGNALS ONLY (owner rule 2026-08-29).
   Live (members): the only prints are triple-lock completions, the exact
   rows the Signals page books — INTRADAY (30m+2h+1d) and SWING (2h+1d+w).
   No single-clock flips, no oscillator calls, no structure chatter, no
   minute-engine telemetry: a line appears when everything is confirmed,
   and only then. Locks print only with a precise completion timestamp
   (daily/weekly-youngest locks are bar-grained — they belong to the
   Signals page book, not a tape). The `flow` prop picks the stream:
   all / intraday / swing. Outside market hours the latest session's
   prints show with an honest "LAST SESSION" badge.
   Demo (public landing): a canned representative loop, badged SAMPLE —
   real data never leaves the paid wall. */

/* A tape line: the ONLY colored ink is the side — the time, ticker and
   set stay quiet, the price anchors the right edge so every line spans
   the card like a real blotter. */
type Line = { ts: number; t: string; sym: string; side: string; set: string; px: string; color: string };

export type TapeFlow = "all" | "intraday" | "swing";

/* Locks complete on bar closes, so seconds are always :00 — print HH:MM. */
const fmtClock = (iso: string) => {
  const d = new Date(iso);
  const p = (x: number) => String(x).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
};

/* One grid for headers and rows: time, ticker, side and set share the
   width evenly so no column floats in a void; price is right-anchored. */
const TAPE_GRID = "56px 1.1fr 1fr 1.4fr 96px";

const PLACEHOLDER: Line = {
  ts: 0,
  t: "--:--",
  sym: "iq.core",
  side: "",
  set: "connecting to the live tape…",
  px: "",
  color: "var(--d-faint, #5C6E93)",
};

/* Triple-lock completions → tape lines. Only rows with a real completion
   timestamp print; the timestamp doubles as the identity, so a lock
   prints once and never re-stamps across feed refreshes. */
function lockLines(
  triples: { sym: string; side: string; price?: number | null; completed_at?: string | null }[] | undefined,
  flow: "intraday" | "swing",
): Line[] {
  if (!triples) return [];
  const set = flow === "intraday" ? "INTRADAY" : "SWING";
  const out: Line[] = [];
  for (const t of triples) {
    if (!t.completed_at) continue;
    const sell = t.side === "bear";
    out.push({
      ts: new Date(t.completed_at).getTime(),
      t: fmtClock(t.completed_at),
      sym: t.sym,
      side: sell ? "SELL ▼" : "BUY ▲",
      set,
      px: typeof t.price === "number" && t.price > 0 ? t.price.toFixed(2) : "",
      color: sell ? "#F23645" : "#089981",
    });
  }
  return out;
}

/* Representative sample for the public landing — the live tape's exact
   vocabulary (locks only), clearly badged SAMPLE. */
const DEMO_LINES: { sym: string; side: string; set: string; px: string }[] = [
  { sym: "NVDA", side: "BUY ▲", set: "INTRADAY", px: "227.98" },
  { sym: "TSLA", side: "SELL ▼", set: "SWING", px: "402.30" },
  { sym: "META", side: "BUY ▲", set: "INTRADAY", px: "812.33" },
  { sym: "AMD", side: "SELL ▼", set: "INTRADAY", px: "289.40" },
  { sym: "MSFT", side: "BUY ▲", set: "SWING", px: "612.44" },
  { sym: "PLTR", side: "BUY ▲", set: "SWING", px: "187.44" },
];

export type TapeAsset = "all" | "stocks" | "crypto";

const isCryptoSym = (s: string) => s.endsWith("-USD");

export default function InferenceTerminal({
  demo = false,
  rows = 4,
  flow = "all",
  asset = "all",
}: {
  /* demo: canned sample loop with a SAMPLE badge (public landing). */
  demo?: boolean;
  /* visible rows. */
  rows?: number;
  /* which lock stream prints. */
  flow?: TapeFlow;
  /* stocks / crypto / all — crypto locks appear once the scan universe
     carries crypto symbols. */
  asset?: TapeAsset;
} = {}) {
  const [demoFeed, setDemoFeed] = useState<Line[]>([PLACEHOLDER]);

  // Demo mode: loop the canned sample instead of touching the live feeds.
  useEffect(() => {
    if (!demo) return;
    let i = 0;
    const iv = setInterval(() => {
      const d = DEMO_LINES[i % DEMO_LINES.length];
      i += 1;
      const line = {
        ts: Date.now(),
        t: fmtClock(new Date().toISOString()),
        sym: d.sym,
        side: d.side,
        set: d.set,
        px: d.px,
        color: d.side.includes("▼") ? "#F23645" : "#089981",
      };
      setDemoFeed((f) => [...f.filter((l) => l.sym !== "iq.core").slice(-(rows - 1)), line]);
    }, 2600);
    return () => clearInterval(iv);
  }, [demo, rows]);

  const intradayQ = useQuery({ ...iqSignalsQuery(), enabled: !demo && flow !== "swing" });
  const swingQ = useQuery({ ...iqSwingSignalsQuery(), enabled: !demo && flow !== "intraday" });

  /* One time-ordered stream of confirmed locks, newest rows win the buffer. */
  const merged = useMemo(() => {
    if (demo) return demoFeed;
    const locks = [
      ...(flow !== "swing" ? lockLines(intradayQ.data?.triples, "intraday") : []),
      ...(flow !== "intraday" ? lockLines(swingQ.data?.triples, "swing") : []),
    ]
      .filter((l) => asset === "all" || (asset === "crypto") === isCryptoSym(l.sym))
      .sort((a, b) => a.ts - b.ts)
      .slice(-rows);
    if (locks.length) return locks;
    return [
      intradayQ.data || swingQ.data
        ? { ...PLACEHOLDER, set: "no completed locks on this stream yet" }
        : PLACEHOLDER,
    ];
  }, [demo, demoFeed, flow, asset, intradayQ.data, swingQ.data, rows]);

  const newest = merged[merged.length - 1];
  const streaming = !!newest && newest.ts > 0 && Date.now() - newest.ts < 5 * 60_000;

  return (
    <div
      style={{
        /* the tape is a terminal — a dark island in BOTH themes. Opaque, not
           glass: the old rgba(9,9,9,.78) composited to muddy gray once the
           page behind it could be light. */
        background: "var(--d-bg, #0D0D0D)",
        border: "1px solid var(--d-line, rgba(255,255,255,.08))",
        borderRadius: 14,
        overflow: "hidden",
        boxShadow: "var(--d-shadow, 0 24px 70px rgba(0,0,0,.5))",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 18px",
          borderBottom: "1px solid var(--d-line, rgba(255,255,255,.06))",
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 11,
          letterSpacing: "0.14em",
        }}
      >
        <span style={{ color: "var(--d-faint, #5C6E93)", textTransform: "uppercase" }}>IQ CORE · LIVE TAPE</span>
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            color: demo ? "#8CA3C5" : streaming ? "#089981" : "var(--d-faint, #5C6E93)",
            textTransform: "uppercase",
          }}
        >
          <span
            style={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: demo ? "#8CA3C5" : streaming ? "#089981" : "var(--d-faint, #5C6E93)",
              boxShadow: !demo && streaming ? "0 0 8px #089981" : undefined,
              animation: !demo && streaming ? "pulse 1.6s ease-in-out infinite" : undefined,
            }}
          />
          {demo ? "SAMPLE" : streaming ? "STREAMING" : "LAST SESSION"}
        </span>
      </div>
      <div
        style={{
          padding: "14px 20px 16px",
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 12.5,
          lineHeight: 1.9,
        }}
      >
        {/* column headers — the same grid template as the rows, so every
            print lands under a labeled column and nothing floats */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: TAPE_GRID,
            gap: 12,
            paddingBottom: 6,
            marginBottom: 6,
            borderBottom: "1px solid var(--d-line, rgba(255,255,255,.06))",
            fontSize: 9,
            letterSpacing: "0.14em",
            color: "var(--d-ghost, #3A4A6B)",
          }}
        >
          <span>TIME</span>
          <span>TICKER</span>
          <span>SIDE</span>
          <span>SET</span>
          <span style={{ textAlign: "right" }}>PRICE</span>
        </div>
        {merged.map((ln, i) =>
          ln.sym === "iq.core" ? (
            <div key={`ph-${i}`} style={{ display: "flex", gap: 14, whiteSpace: "nowrap" }}>
              <span style={{ color: "var(--d-faint, #5C6E93)", flexShrink: 0 }}>{ln.t}</span>
              <span style={{ color: "var(--d-faint, #5C6E93)" }}>{ln.set}</span>
            </div>
          ) : (
            <div
              key={`${ln.ts}-${ln.sym}-${i}`}
              style={{ display: "grid", gridTemplateColumns: TAPE_GRID, gap: 12, whiteSpace: "nowrap", overflow: "hidden" }}
            >
              <span style={{ color: "var(--d-faint, #5C6E93)" }}>{ln.t}</span>
              <span style={{ color: "var(--d-ink, #EAF1FC)", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis" }}>
                {ln.sym}
              </span>
              <span style={{ color: ln.color, fontWeight: 600 }}>{ln.side}</span>
              <span style={{ color: "var(--d-faint, #5C6E93)", overflow: "hidden", textOverflow: "ellipsis" }}>{ln.set}</span>
              <span style={{ color: "var(--d-ink, #EAF1FC)", textAlign: "right" }}>{ln.px}</span>
            </div>
          ),
        )}
      </div>
    </div>
  );
}
